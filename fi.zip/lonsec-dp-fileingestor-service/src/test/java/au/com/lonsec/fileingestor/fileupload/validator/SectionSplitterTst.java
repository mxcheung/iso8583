package au.com.lonsec.fileingestor.fileupload.validator;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.FileUtils;

public class SectionSplitterTst {

    protected String getFileSpecJSON(String filepath) throws IOException {
        return FileUtils.readFileToString(new File(filepath), StandardCharsets.UTF_8);
    }

}
