package au.com.lonsec.fileingestor.filespec.model;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.FileUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.util.JSONHelper;

public class ReportDefinitionTst {
    
    protected static final String FILESPEC_FILEPATH = "src\\test\\resources\\filespec\\portfolioHoldingDef.json";
    
    protected static final String FUND_NAME = "fundName";
    protected static final String APIR_CODE = "apirCd";
    
    protected static final String APIR_CD = "apirCd";
    
    protected ObjectMapper mapper;
    
    protected ObjectMapper getObjectMapper() {
        return JSONHelper.getObjectMapper();
    }

    protected ReportDefinition getReportDefinition() {
        return DomainStereotypeUtil.getReportDefinition();
    }
    
    protected String getFileSpecJSON() throws IOException {
        return FileUtils.readFileToString(new File(FILESPEC_FILEPATH), StandardCharsets.UTF_8);
    }


    

    
}
