package au.com.lonsec.fileingestor.poi;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.filespec.model.ColumnDefinition;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;

public class HoldingEquityIngesterTest {

	private static final Logger LOGGER = LoggerFactory.getLogger(HoldingEquityIngesterTest.class);

	private static final String XSSF_RESOURCE = "/xssf/lonsec/Holding Equity 456_20171106012756.xls";
	private static final String XSSF_WITH_GAP_RESOURCE = "/xssf/lonsec/Holding Equity 456_20171106012756_with_gaps.xls";

	private InputStream excelFileToRead;

	private PoiService poiService;

	private List<Sheet> wbData;

	@Before
	public void setup() throws Exception {
		poiService = new PoiService();
		excelFileToRead = getClass().getResourceAsStream(XSSF_RESOURCE);
		wbData = poiService.extractSheets(excelFileToRead, "xls");
	}

	@Test
	public void testEquityWorkSheet() throws IOException, OpenXML4JException {
		assertEquals(2, wbData.size());
		Sheet sheet = wbData.get(0);
		ReportDefinition reportDefinition = createReportDefinition();
		int headerStartRow = 0;
		int dataStartRow = 1;
		reportDefinition.setHeaderStartRow(headerStartRow);
		reportDefinition.setDataStartRow(dataStartRow);
		Row row = poiService.getRow(sheet, reportDefinition.getHeaderStartRow());
		List<ColumnDefinition> columns = reportDefinition.getColumnDefinitions();
		Map<String, Integer> headersMap = poiService.getRowToHeadersMap(row);
		assertEquals(12, headersMap.size());
		columns = poiService.mapColumns(columns, headersMap);
		assertEquals(7, columns.size());
		verifyColumnDefiniton(columns, 0, "APIR Code", 0);
		verifyColumnDefiniton(columns, 1, "Fund Name", 1);
		verifyColumnDefiniton(columns, 2, "SEDOL", 2);
		verifyColumnDefiniton(columns, 3, "Security Name", 3);
		verifyColumnDefiniton(columns, 4, "Absolute Portfolio Weight (%)", 4);
		verifyColumnDefiniton(columns, 5, "Relative Portfolio Weight (%)", 5);
		verifyColumnDefiniton(columns, 6, "Holding Date", 6);
	}

	@Test
	public void testEquityWithGapsWorkSheet() throws IOException, OpenXML4JException {
		ObjectMapper objectMapper = getObjectMapper();
		excelFileToRead = getClass().getResourceAsStream(XSSF_WITH_GAP_RESOURCE);
		wbData = poiService.extractSheets(excelFileToRead, "xls");
		assertEquals(4, wbData.size());
		Sheet sheet = wbData.get(0);
		ReportDefinition reportDefinition = createReportDefinition();
		int headerStartRow = 6;
		int dataStartRow = 7;
		reportDefinition.setHeaderStartRow(headerStartRow);
		reportDefinition.setDataStartRow(dataStartRow);
		Row row = poiService.getRow(sheet, reportDefinition.getHeaderStartRow());

		List<ColumnDefinition> columns = reportDefinition.getColumnDefinitions();
		Map<String, Integer> headersMap = poiService.getRowToHeadersMap(row);
		assertEquals(12, headersMap.size());
		columns = poiService.mapColumns(columns, headersMap);
		assertEquals(7, columns.size());
		verifyColumnDefiniton(columns, 0, "APIR Code", 0);
		verifyColumnDefiniton(columns, 1, "Fund Name", 1);
		verifyColumnDefiniton(columns, 2, "SEDOL", 2);
		verifyColumnDefiniton(columns, 3, "Security Name", 4);
		verifyColumnDefiniton(columns, 4, "Absolute Portfolio Weight (%)", 5);
		verifyColumnDefiniton(columns, 5, "Relative Portfolio Weight (%)", 6);
		verifyColumnDefiniton(columns, 6, "Holding Date", 7);

		Row dataRow = poiService.getRow(sheet, reportDefinition.getHeaderStartRow() + 1);
		HashMap<String, Object> data = poiService.rowToMap(reportDefinition.getColumnDefinitions(), dataRow);


		List<Map<String, Object>> dataRows = poiService.getDataRows(sheet, reportDefinition.getColumnDefinitions(),
				reportDefinition.getDataStartRow());

		

	}



	public static ObjectMapper getObjectMapper() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		mapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
		mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
		return mapper;
	}

	private ReportDefinition createReportDefinition() {
		return DomainStereotypeUtil.getReportDefinition();
	}


	private void verifyColumnDefiniton(List<ColumnDefinition> columns, Integer index, String expectedSourceName,
			Integer expectedColumnIdx) {
		ColumnDefinition fundNamecolDef = columns.get(index);
		assertEquals(expectedSourceName, fundNamecolDef.getSourceName());
		assertEquals(expectedColumnIdx, fundNamecolDef.getColumnIdx());
	}


}
