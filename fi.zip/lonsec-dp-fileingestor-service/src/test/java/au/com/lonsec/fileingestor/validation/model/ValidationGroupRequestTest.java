package au.com.lonsec.fileingestor.validation.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.fileupload.model.ValidationDTO;

public class ValidationGroupRequestTest extends ValidationRequestTst  {


    private final static String JSON_STRING = "{\"validationDTO\":{\"data\":{\"securityName\":\"BOOZ ALLEN\",\"apirCd\":\"apirCd123\",\"isin\":\"US0378331004\"},\"containsErrors\":false,\"dataRows\":[{\"securityName\":\"BOOZ ALLEN\",\"relPortfolioWeight\":\"0.45\",\"apirCd\":\"apirCd123\",\"absPortfolioWeight\":\"0.12\"},{\"securityName\":\"BOOZ ALLEN\",\"relPortfolioWeight\":\"0.45\",\"apirCd\":\"apirCd123\",\"absPortfolioWeight\":\"0.12\"}]},\"validationRules\":[{\"key\":\"apirCd\",\"expression\":\"apirCd.length() > 9\",\"message\":\"apirCd  must be between 0 and 9 characters\"},{\"key\":\"securityName\",\"expression\":\"securityName.length() > 20 \",\"message\":\"securityName  must be between 0 and 20 characters\"},{\"key\":\"#isin\",\"expression\":\"#isValidISIN(#isin)\",\"message\":\"isin  ${validatedValue}  check digit is invalid\"}]}";

    private ObjectMapper mapper;

    @Before
    public void setup() {
        mapper = new ObjectMapper();
    }

    @Test
    public void shouldSerialize() throws JsonProcessingException {
        ValidationRequest validationRequest = getValidationRequest();
        ValidationDTO groupData = validationRequest.getValidationDTO();
        List<Map<String, Object>> dataRows = DomainStereotypeUtil.getDataRows();
        dataRows.add(DomainStereotypeUtil.getDataRow());
        
        groupData.setDataRows(dataRows);
        List<ValidationRule> validationRules = validationRequest.getValidationRules();
        String json = this.mapper.writeValueAsString(validationRequest);
        assertNotNull(groupData);
        assertEquals(3, validationRules.size());
        assertEquals(JSON_STRING, json);
    }

    @Test
    public void shouldDeserialize() throws JSONException, JsonParseException, JsonMappingException, IOException {
        ValidationRequest validationRule = mapper.readValue(JSON_STRING, ValidationRequest.class);
        Map<String, Object> data = validationRule.getValidationDTO().getData();
        assertEquals("apirCd123", data.get(APIR_CD));
    }


}
