package au.com.lonsec.fileingestor.fileupload.model;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;

public class FileUploadTst {

    protected FileDTO fileDTO;

    protected BatchDTO batchDTO;

    protected DataSetDTO dataSetDTO;

    protected SectionDTO sectionDTO;

    protected ResultDTO resultDTO;
    
    protected String ORIGINAL_FILE_NAME = DomainStereotypeUtil.ORIGINAL_FILE_NAME;

    protected BatchDTO getBatchDTO() {
        return DomainStereotypeUtil.getBatchDTO();
    }

    protected FileDTO getFileDTO() {
        return DomainStereotypeUtil.getFileDTO();
    }

    protected DataSetDTO getDataSetDTO() {
        return DomainStereotypeUtil.getDataSetDTO();
    }

    protected SectionDTO getSectionDTO() {
        return DomainStereotypeUtil.getSectionDTO();
    }

    protected ResultDTO getResultDTO() {
        return DomainStereotypeUtil.getResultDTO();
    }

}
