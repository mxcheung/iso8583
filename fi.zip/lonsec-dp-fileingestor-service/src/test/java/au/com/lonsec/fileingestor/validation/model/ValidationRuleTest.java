package au.com.lonsec.fileingestor.validation.model;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ValidationRuleTest extends ValidationRuleTst  {


    private final static String JSON_STRING = "{\"key\":\"apirCd\",\"expression\":\"apirCd.length() > 9\",\"message\":\"apirCd  must be between 0 and 9 characters\"}";

    private ObjectMapper mapper;

    @Before
    public void setup() {
        mapper = new ObjectMapper();
    }

    @Test
    public void shouldSerialize() throws JsonProcessingException {
        ValidationRule validationRule = getValidationRule();
        String json = this.mapper.writeValueAsString(validationRule);
        assertEquals(JSON_STRING, json);
    }

    @Test
    public void shouldDeserialize() throws JSONException, JsonParseException, JsonMappingException, IOException {
        ValidationRule validationRule = mapper.readValue(JSON_STRING, ValidationRule.class);
        assertEquals(APIR_CD, validationRule.getKey());
    }


}
