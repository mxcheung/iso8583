package au.com.lonsec.fileingestor.fileupload.validator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Sheet;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.filespec.FileSpecConfig;
import au.com.lonsec.fileingestor.filespec.model.ColumnDefinition;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.fileupload.model.DataSetDTO;
import au.com.lonsec.fileingestor.fileupload.model.SectionDTO;
import au.com.lonsec.fileingestor.poi.PoiService;

@RunWith(MockitoJUnitRunner.class)
public class SheetValidatorTest {

	private SheetValidator sheetValidator;

	private static final String XSSF_RESOURCE = "/xssf/test/MissingMapWith_gaps.xls";

	private InputStream excelFileToRead = getClass().getResourceAsStream(XSSF_RESOURCE);

	private PoiService xSSFDataService;
	private List<Sheet> wbData;

	@Mock
	FileSpecConfig config;

	@Mock
	private SectionValidator sectionValidator;

	@Mock
	private RowValidator rowValidator;

	@Mock
	private PoiService poiService;

	private Sheet sheet;

	@Mock
	private SectionSplitter sectionSplitter;

	private Map<String, String> filespecs;

	private ReportDefinition reportDefinition;

	@Before
	public void setup() throws InvalidFormatException, IOException {
		filespecs = new HashMap<String, String>();
		filespecs.put("portfolioHoldingDef", "filespec/portfolioHoldingDef.json");
		when(config.getFilespecs()).thenReturn(filespecs);
		sheetValidator = new SheetValidator(poiService, sectionValidator, sectionSplitter);
		reportDefinition = DomainStereotypeUtil.getReportDefinition();
		xSSFDataService = new PoiService();
		wbData = xSSFDataService.extractSheets(excelFileToRead, "xls");
	}

	@Test
	public void shouldValidateSheet() {
		sheet = wbData.get(0);
		List<DataSetDTO> result = sheetValidator.validateSheet(reportDefinition, sheet);
		assertEquals(0, result.size());
		List<ColumnDefinition> columns = reportDefinition.getColumnDefinitions();
		for (ColumnDefinition column : columns) {
			column.setColumnIdx(1);
		}
		reportDefinition.setColumnDefinitions(columns);
		result = sheetValidator.validateSheet(reportDefinition, sheet);
		assertEquals(0, result.size());
	}

	@Test
	public void shouldIsColumnMapped() {
		List<ColumnDefinition> columns = reportDefinition.getColumnDefinitions();
		assertFalse(sheetValidator.isColumnsMapped(columns));
		for (ColumnDefinition column : columns) {
			column.setColumnIdx(1);
		}
		assertTrue(sheetValidator.isColumnsMapped(columns));
	}

	@Test
	public void shouldValidationSection() {
		List<SectionDTO> sections = DomainStereotypeUtil.getSectionDTOs();
		List<DataSetDTO> result = sheetValidator.validateSections(reportDefinition, sections);
		assertEquals(1, result.size());
	}
}
