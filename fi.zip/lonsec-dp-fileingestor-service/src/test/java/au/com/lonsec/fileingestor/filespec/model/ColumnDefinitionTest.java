package au.com.lonsec.fileingestor.filespec.model;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ColumnDefinitionTest extends ColumnDefinitionTst  {


    private final static String JSON_STRING = "{\"sourceName\":\"sourceName\",\"columnIdx\":0}";

    private ObjectMapper mapper;

    @Before
    public void setup() {
        mapper = new ObjectMapper();
    }

    @Test
    public void shouldSerialize() throws JsonProcessingException {
        ColumnDefinition columnsDTO = getColumnDefinition();
        String json = this.mapper.writeValueAsString(columnsDTO);
        assertEquals(JSON_STRING, json);
    }

    @Test
    public void shouldDeserialize() throws JSONException, JsonParseException, JsonMappingException, IOException {
        ColumnDefinition columnsDTO = mapper.readValue(JSON_STRING, ColumnDefinition.class);
        assertEquals(SOURCE_NAME, columnsDTO.getSourceName());
    }


}
