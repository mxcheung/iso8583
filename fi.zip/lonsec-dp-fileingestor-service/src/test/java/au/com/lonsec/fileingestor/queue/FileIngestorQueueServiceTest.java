package au.com.lonsec.fileingestor.queue;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;

import java.util.concurrent.BlockingQueue;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import au.com.lonsec.fileingestor.fileupload.QueueItemEntity;

@RunWith(MockitoJUnitRunner.class)
public class FileIngestorQueueServiceTest {

    private FileIngestorQueueService fileIngestorQueueService;
    
    @Mock
    private BlockingQueue<QueueItemEntity> mockQueue;
    
    @Before
    public void setup() {
        fileIngestorQueueService = new FileIngestorQueueService();
    }

    @Test
    public void shouldAddItem() throws InterruptedException{
        QueueItemEntity queueItemEntity = new QueueItemEntity();
        Long fileId = 1L;
        queueItemEntity.setFileId(fileId);
        fileIngestorQueueService.setQueue(mockQueue);
        fileIngestorQueueService.put(queueItemEntity);
        fileIngestorQueueService.take();
        
        BlockingQueue<QueueItemEntity> actual = fileIngestorQueueService.getQueue();
        verify(mockQueue, times(1)).put(queueItemEntity);
        verify(mockQueue, times(1)).take();
        verifyNoMoreInteractions(mockQueue);
        assertEquals(actual, mockQueue);
    }


}
