package au.com.lonsec.fileingestor.validation.model;

import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.util.JSONHelper;

public class ValidationRuleTst {

    protected static final String APIR_CD = "apirCd";

    protected ObjectMapper getObjectMapper() {
        return JSONHelper.getObjectMapper();
    }

    protected ValidationRule getValidationRule() {
    	return DomainStereotypeUtil.getValidationRule();
    }
    
}
