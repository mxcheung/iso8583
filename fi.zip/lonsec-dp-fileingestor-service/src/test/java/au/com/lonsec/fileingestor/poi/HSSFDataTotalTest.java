package au.com.lonsec.fileingestor.poi;

import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.junit.Before;
import org.junit.Test;

import au.com.lonsec.fileingestor.fileupload.model.SpelDataRowsDTO;
import au.com.lonsec.fileingestor.validation.util.SpelFunctions;

public class HSSFDataTotalTest {

	private static final String XLSX_RESOURCE = "/xssf/test/calc/Lonsec_HoldingsSummary.m.20171031_v3.xlsx";

	private static final String XLS_RESOURCE = "/xssf/test/calc/Lonsec_HoldingsSummary.m.20171031_v5_xls.xls";

	private InputStream excelFileToRead = getClass().getResourceAsStream(XLSX_RESOURCE);

	private PoiService xSSFDataService;

	@Before
	public void setup() throws Exception {
		xSSFDataService = new PoiService();
	}

	@Test
	public void testXLSXCalc() throws IOException, OpenXML4JException {
		RowMapper rowMapper = new RowMapper();
		excelFileToRead = getClass().getResourceAsStream(XLSX_RESOURCE);
		List<Sheet> wbData = xSSFDataService.extractSheets(excelFileToRead, "xlsx");
		BigDecimal total = BigDecimal.ZERO;
		Sheet sheet = wbData.get(0);
		for (Row row : sheet) {
			Cell cell = row.getCell(10);
			Object x = rowMapper.getCellValue(cell);
			BigDecimal bd = new BigDecimal(x.toString());
			total = total.add(bd);
		}
		assertTrue(SpelFunctions.isValueWithinThresHold(total.toString(), "100", "0.00001"));
	}

	@Test
	public void testXlsCalcTotalWithScientificNotation() throws IOException, OpenXML4JException {
		excelFileToRead = getClass().getResourceAsStream(XLS_RESOURCE);
		List<Map<String, Object>> dataRows = new ArrayList<Map<String, Object>>();
		String key = "prct";
		RowMapper rowMapper = new RowMapper();
		List<Sheet> wbData = xSSFDataService.extractSheets(excelFileToRead, "xls");
		BigDecimal total = BigDecimal.ZERO;
		Sheet sheet = wbData.get(0);
		for (Row row : sheet) {
			Cell cell = row.getCell(10);
			Object obj = rowMapper.getCellValue(cell);
			Map<String, Object> dataRow = new HashMap<String, Object>();
			dataRow.put(key, obj);
			dataRows.add(dataRow);
			BigDecimal bd = new BigDecimal(obj.toString()).setScale(15, RoundingMode.UP);
			total = total.add(bd);
		}

		SpelDataRowsDTO juelDataRowsDTO = new SpelDataRowsDTO();
		juelDataRowsDTO.setDataRows(dataRows);
		BigDecimal calcTotal = SpelFunctions.calcTotal(juelDataRowsDTO, key);
		assertTrue(SpelFunctions.isValueWithinThresHold(calcTotal.toString(), "100", "0.00001"));
	}
	
}
