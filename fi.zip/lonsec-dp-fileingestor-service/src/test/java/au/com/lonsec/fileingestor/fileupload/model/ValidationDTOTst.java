package au.com.lonsec.fileingestor.fileupload.model;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;

public class ValidationDTOTst {

    protected static final String APIR_CD = "apirCd";
    
    protected ValidationDTO getValidationDTO() {
        return DomainStereotypeUtil.getValidationDTO();
    }

}
