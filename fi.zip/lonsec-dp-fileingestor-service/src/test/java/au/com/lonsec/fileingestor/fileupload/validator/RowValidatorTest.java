package au.com.lonsec.fileingestor.fileupload.validator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.filespec.FileSpecConfig;
import au.com.lonsec.fileingestor.filespec.model.ColumnDefinition;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.fileupload.model.ValidationDTO;
import au.com.lonsec.fileingestor.fileupload.model.ValidationError;
import au.com.lonsec.fileingestor.validation.server.ValidationService;

@RunWith(MockitoJUnitRunner.class)
public class RowValidatorTest {

	private RowValidator rowValidator;

	@Mock
	FileSpecConfig config;

	@Mock
	private ValidationService validationService;

	private Map<String, String> filespecs;

	private ReportDefinition reportDefinition;

	private List<ValidationDTO> validationDTOs;

	@Before
	public void setup() {
		filespecs = new HashMap<String, String>();
		filespecs.put("portfolioHoldingDef", "filespec/portfolioHoldingDef.json");
		when(config.getFilespecs()).thenReturn(filespecs);
		rowValidator = new RowValidator(validationService);
		reportDefinition = DomainStereotypeUtil.getReportDefinition();
		validationDTOs = DomainStereotypeUtil.getValidationDTOs();

	}

    @Test
    public void shouldValidateRows() {
        rowValidator.validateRows(reportDefinition, validationDTOs);
        List<ColumnDefinition> columns = reportDefinition.getColumnDefinitions();
        assertTrue(rowValidator.getColumnByTargetName(columns, "apirCd").isPresent());
        assertFalse(rowValidator.getColumnByTargetName(columns, "xx").isPresent());
    }

    @Test
    public void shouldUpdateColumnNumberValidationError() {
    	List<ColumnDefinition> columns = reportDefinition.getColumnDefinitions();
    	List<ValidationError> validationErrors = DomainStereotypeUtil.getValidationErrors();
         List<ColumnDefinition> result = rowValidator.updateColumnNumberValidationError(columns, validationErrors);
         assertEquals(7, result.size());
    }

}
