package au.com.lonsec.fileingestor.util;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;

import org.junit.Before;
import org.junit.Test;


public class FileUtilTest  {


    @Before
    public void setup() {
    }
    
    @Test
    public void shouldCompress() throws IOException {
        String uncompressedData = "Test";
        byte[] compressedData = FileUtil.gzipCompress(uncompressedData.getBytes());
        byte[] result = FileUtil.gzipUncompress(compressedData);
        assertEquals(uncompressedData, new String(result));
    }
    
  
    @Test(expected = IOException.class)
    public void shouldRaiseExceptionWhenDataNotGzipFormat() throws IOException {
        byte[] compressedData = "Test".getBytes();
        FileUtil.gzipUncompress(compressedData);
    }
    

    @Test
    public void testConstructorIsPrivate() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Constructor<FileUtil> constructor = FileUtil.class.getDeclaredConstructor();
        assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);
        constructor.newInstance();
    }
    
  
}
