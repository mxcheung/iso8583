package au.com.lonsec.fileingestor.fileupload;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.fileupload.model.FileDTO;

public class FileMapperTest {

    private FileMapper fileMapper;

    @Before
    public void setup() throws IOException {
        fileMapper = new FileMapper();
    }

    @Test
    public void shouldConverTFileEntity() {
        FileEntity expected = DomainStereotypeUtil.getFileEntity();
        FileDTO actual = fileMapper.map(expected, new FileDTO());
        assertEquals(expected.getId(),actual.getId());
        assertEquals(expected.getOriginalFileName(),actual.getOriginalFileName());
        assertEquals(expected.getStatus(),actual.getStatus());
        assertEquals(expected.getFailReason(),actual.getFailReason());
        assertEquals(expected.getTotalDatasets(),actual.getTotalDatasets());
        assertEquals(expected.getErrorDatasets(),actual.getErrorDatasets());
    }

}
