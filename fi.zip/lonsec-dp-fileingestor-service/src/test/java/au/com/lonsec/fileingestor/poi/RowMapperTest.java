package au.com.lonsec.fileingestor.poi;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.FormulaError;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class RowMapperTest extends RowMapperTst {

    private static final int HEADER_ROW_INDEX = 0;
    private static final int CELL_TEST_ROW_INDEX = 1;
    private static final int EMPTY_ROW_INDEX = 2;
    
    @Mock
    private Cell mockCell;

    @Before
    public void setup() throws Exception {
        rowMapper = new RowMapper();
        sheet = getXLSSheet();
        row = getXlsRow(HEADER_ROW_INDEX);
    }

    @Test
    public void testEmptyrow() throws IOException, OpenXML4JException {
        row = getXlsRow(EMPTY_ROW_INDEX);
        assertTrue(rowMapper.isRowEmpty(row));
    }

    @Test
    public void testRowWithBlankCellEmptyrow() throws IOException, OpenXML4JException {
        row = getXlsRow(EMPTY_ROW_INDEX);
        row.createCell(0);
        assertTrue(rowMapper.isRowEmpty(row));
    }

    @Test
    public void testNonEmptyrow() throws IOException, OpenXML4JException {
        row = getXlsRow(HEADER_ROW_INDEX);
        assertFalse(rowMapper.isRowEmpty(row));
    }

    @Test
    public void testCellType() throws IOException, OpenXML4JException {
        row = getXlsRow(CELL_TEST_ROW_INDEX);
        assertFalse(rowMapper.isRowEmpty(row));
        assertEquals(13, row.getPhysicalNumberOfCells());
        assertEquals("Hello", rowMapper.getCellValue(row.getCell(0)));
    }

    @Test
    public void testCellValue() throws IOException, OpenXML4JException {
        row = getXlsRow(HEADER_ROW_INDEX);
        Cell cell = row.getCell(0);
        cell.setCellValue(true);
        assertEquals(true, rowMapper.getCellValue(cell));
        cell.setCellValue(1.2);
        assertEquals(1.2, rowMapper.getCellValue(cell));
        assertNull(rowMapper.getCellValue(null));
        cell.setCellFormula("1=2");
        assertEquals(0.0, rowMapper.getCellValue(cell));

        Cell cell0 = row.createCell(0);
        cell0.setCellValue(Double.NaN);
        assertEquals(FormulaError.NUM.getCode(), rowMapper.getCellValue(cell0));
    }

    @Test
    public void testCellFormulaValue() throws IOException, OpenXML4JException {
        row = getXlsRow(4);
        Cell cell = row.getCell(6);
        assertEquals(0.00815, rowMapper.getCellFormulaValue(cell));
        assertEquals("AKAMAI TECHNOLOGIES", rowMapper.getCellFormulaValue(row.getCell(4)));
        assertEquals(0.00834, rowMapper.getCellFormulaValue(row.getCell(5)));
        assertEquals(0.00815, rowMapper.getCellFormulaValue(row.getCell(6)));
        assertEquals("30/09/2017", rowMapper.getCellFormulaValue(row.getCell(7)));
        assertEquals(FormulaError.DIV0.getCode(), rowMapper.getCellFormulaValue(row.getCell(8)));
        assertEquals(true, rowMapper.getCellFormulaValue(row.getCell(9)));
        assertNull(rowMapper.getCellFormulaValue(null));
    }

    @Test
    public void testCellTypeValue() throws IOException, OpenXML4JException {
        row = getXlsRow(HEADER_ROW_INDEX);
        Cell cell = row.getCell(0);
        cell.setCellValue(true);
        assertNull( rowMapper.getCellValue(cell, CellType._NONE));
               assertNull( rowMapper.getCellValue(null, CellType.BOOLEAN));
        assertEquals(true, rowMapper.getCellValue(cell, CellType.BOOLEAN));
    }
    
    @Test
    public void testCellTypeNone()  {
        when(mockCell.getCellTypeEnum()).thenReturn(org.apache.poi.ss.usermodel.CellType._NONE);
        assertNull(rowMapper.getCellValue(mockCell));
    }
    



}
