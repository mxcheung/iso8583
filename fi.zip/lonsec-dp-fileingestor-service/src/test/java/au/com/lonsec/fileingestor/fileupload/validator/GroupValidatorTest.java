package au.com.lonsec.fileingestor.fileupload.validator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.filespec.FileSpecConfig;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.fileupload.model.ValidationDTO;
import au.com.lonsec.fileingestor.fileupload.model.ValidationError;
import au.com.lonsec.fileingestor.validation.model.ValidationRule;
import au.com.lonsec.fileingestor.validation.server.ValidationService;

@RunWith(MockitoJUnitRunner.class)
public class GroupValidatorTest {

	private GroupValidator groupValidator;

	@Mock
	FileSpecConfig config;

	@Mock
	private ValidationService validationService;

	private Map<String, String> filespecs;

	private ReportDefinition reportDefinition;


	private List<Map<String, Object>> dataRows;
	
	@Before
	public void setup() {
		filespecs = new HashMap<String, String>();
		filespecs.put("portfolioHoldingDef", "filespec/portfolioHoldingDef.json");
		when(config.getFilespecs()).thenReturn(filespecs);
		groupValidator = new GroupValidator(validationService);
		reportDefinition = DomainStereotypeUtil.getReportDefinition();
		dataRows = DomainStereotypeUtil.getDataRows();

	}

	@Test
	public void shouldValidateGroupItemWithErrors() {
		List<ValidationError> validationErrors = DomainStereotypeUtil.getValidationErrors() ;
		ValidationDTO validationDTO = DomainStereotypeUtil.getValidationDTO();
		validationDTO.setGroupName("GroupValidation");
		validationDTO.setDataRows(dataRows);
		List<ValidationRule> validationRules = reportDefinition.getSectionValidationRules();
		when(validationService.validationGroupItem(validationDTO , validationRules)).thenReturn(validationErrors);
		ValidationDTO result = groupValidator.validateGroupData(reportDefinition, validationDTO);
		assertEquals(1, result.getValidationErrors().size());
		assertTrue(result.isContainsErrors());
	}
	

	@Test
	public void shouldValidateGroupItemWithNoErrors() {
		List<ValidationError> validationErrors = new ArrayList<ValidationError>();
		ValidationDTO validationDTO = DomainStereotypeUtil.getValidationDTO();
		validationDTO.setGroupName("GroupValidation");
		validationDTO.setDataRows(dataRows);
		List<ValidationRule> validationRules = reportDefinition.getSectionValidationRules();
		when(validationService.validationGroupItem(validationDTO , validationRules)).thenReturn(validationErrors);
		ValidationDTO result = groupValidator.validateGroupData(reportDefinition, validationDTO);
		assertEquals(0, result.getValidationErrors().size());
		assertFalse(result.isContainsErrors());
	}
	


}
