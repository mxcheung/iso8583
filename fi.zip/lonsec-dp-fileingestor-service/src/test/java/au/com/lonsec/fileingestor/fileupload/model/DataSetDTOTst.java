package au.com.lonsec.fileingestor.fileupload.model;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;

public class DataSetDTOTst {

	protected DataSetDTO dataSetDTO;
	
	protected SectionDTO sectionDTO;
	
	
	protected DataSetDTO getDataSetDTO() {
		return DomainStereotypeUtil.getDataSetDTO();
	}

	protected SectionDTO getSectionDTO() {
		return DomainStereotypeUtil.getSectionDTO();
	}

}
