package au.com.lonsec.fileingestor.fileupload;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;

@RunWith(MockitoJUnitRunner.class)
public class FileServiceTest {

    private FileService fileService;

    @Mock
    private FileRepository fileRepository;

    private FileEntity fileEntity;

    private List<FileEntity> fileEntitys;

    private BatchEntity batchEntity;

    @Before
    public void setup() {
        fileService = new FileService(fileRepository);
        fileEntity = DomainStereotypeUtil.getFileEntity();
        fileEntitys = DomainStereotypeUtil.getFileEntities();
        batchEntity = DomainStereotypeUtil.getBatchEntity();
    }

    @Test
    public void shouldFetchFileEntity() {
        Long fileId = 1L;
        when(fileRepository.findOne(fileId)).thenReturn(fileEntity);
        FileEntity actual = fileService.fetchFileEntity(fileId);
        verify(fileRepository, times(1)).findOne(fileId);
        verifyNoMoreInteractions(fileRepository);
        assertEquals(fileEntity.getId(), actual.getId());
        assertEquals(fileEntity.getOriginalFileName(), actual.getOriginalFileName());
        assertEquals(fileEntity.getBatchId(), actual.getBatchId());
        assertEquals(fileEntity.getStatus(), actual.getStatus());
        assertEquals(fileEntity.getFailReason(), actual.getFailReason());
        assertEquals(fileEntity.getTotalDatasets(), actual.getTotalDatasets());
        assertEquals(fileEntity.getErrorDatasets(), actual.getErrorDatasets());
        assertEquals(fileEntity.getFileContentEntity(), actual.getFileContentEntity());
        assertEquals(fileEntity.getInsertDate(), actual.getInsertDate());
        assertEquals(fileEntity.getLastModified(), actual.getLastModified());
    }

    @Test
    public void shouldFetchFilesByBatchId() {
        Long batchId = batchEntity.getId();
        when(fileRepository.findByBatchId(batchId)).thenReturn(fileEntitys);
        List<FileEntity> result = fileService.findByBatchId(batchId);
        verify(fileRepository, times(1)).findByBatchId(batchId);
        verifyNoMoreInteractions(fileRepository);
        assertEquals(1, result.size());
    }

    @Test
    public void shouldSaveFile() {
        when(fileRepository.save(fileEntity)).thenReturn(fileEntity);
        FileEntity actual = fileService.save(fileEntity);
        verify(fileRepository, times(1)).save(any(FileEntity.class));
        verifyNoMoreInteractions(fileRepository);
        assertEquals(fileEntity.getOriginalFileName(), actual.getOriginalFileName());
    }

}
