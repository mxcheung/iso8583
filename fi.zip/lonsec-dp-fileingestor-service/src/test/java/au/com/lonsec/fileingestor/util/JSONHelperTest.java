package au.com.lonsec.fileingestor.util;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;


public class JSONHelperTest  {

    protected static final String FILESPEC_FILEPATH = "src\\test\\resources\\filespec\\portfolioHoldingDef.json";

    private ObjectMapper mapper;

    @Before
    public void setup() {
        mapper = JSONHelper.getObjectMapper();
    }
    
    @Test
    public void shouldDeserializeFileSpec() throws IOException {
        String json = getFileSpecJSON();
        ReportDefinition reportDefinition = mapper.readValue(json, ReportDefinition.class);
        assertEquals(8, reportDefinition.getColumnDefinitions().size());
    }
    
    protected String getFileSpecJSON() throws IOException {
        return FileUtils.readFileToString(new File(FILESPEC_FILEPATH), StandardCharsets.UTF_8);
    }


    @Test
    public void testConstructorIsPrivate() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Constructor<JSONHelper> constructor = JSONHelper.class.getDeclaredConstructor();
        assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);
        constructor.newInstance();
    }
    
    @Test
    public void tesccctConstructorIsPrivate() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        BigDecimal total = new BigDecimal("100.0000000000000489");
        BigDecimal y = total.setScale(2, RoundingMode.UP);
        BigDecimal z = total.setScale(2, RoundingMode.CEILING);
        assertEquals("100.01", z.toString());
    }

}
