package au.com.lonsec.fileingestor.fileupload.validator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.filespec.FileSpecConfig;
import au.com.lonsec.fileingestor.filespec.model.ColumnDefinition;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.fileupload.model.SectionDTO;
import au.com.lonsec.fileingestor.poi.PoiService;
import au.com.lonsec.fileingestor.util.JSONHelper;

@RunWith(MockitoJUnitRunner.class)
public class SectionSplitterTest extends SectionSplitterTst {

    private static final String XLSX_RESOURCE = "/xssf/blackrock/Lonsec_HoldingsSummary.m.20171031.xlsx";

    protected static final String ROW_LEVEL_FILEPATH = "src\\test\\resources\\filespec\\blackrock_HoldingsSummaryDef.json";

    private InputStream excelFileToRead = getClass().getResourceAsStream(XLSX_RESOURCE);

    private SectionSplitter sectionSplitter;

    @Mock
    FileSpecConfig config;

    private PoiService poiService;

    @Mock
    private Sheet sheet;

    private Map<String, String> filespecs;

    private ReportDefinition reportDefinition;

    private ObjectMapper mapper;

    @Before
    public void setup() {
        filespecs = new HashMap<String, String>();
        filespecs.put("portfolioHoldingDef", "filespec/blackrock_HoldingsSummaryDef.json");
        when(config.getFilespecs()).thenReturn(filespecs);
        reportDefinition = DomainStereotypeUtil.getReportDefinition();
        sectionSplitter = new SectionSplitter();
        poiService = new PoiService();
        mapper = JSONHelper.getObjectMapper();
    }

    @Test
    public void shouldSplitSection() throws InvalidFormatException, IOException {
        String json = getFileSpecJSON(ROW_LEVEL_FILEPATH);
        reportDefinition = mapper.readValue(json, ReportDefinition.class);
        List<ColumnDefinition> columns = reportDefinition.getColumnDefinitions();
        excelFileToRead = getClass().getResourceAsStream(XLSX_RESOURCE);
        List<Sheet> wbData = poiService.extractSheets(excelFileToRead, "xlsx");
        Sheet sheet = wbData.get(0);
        Row row = poiService.getRow(sheet, reportDefinition.getHeaderStartRow());

        Map<String, Integer> headersMap = poiService.getRowToHeadersMap(row);
        columns = poiService.mapColumns(columns, headersMap);
        List<Map<String, Object>> dataRows = poiService.getDataRows(sheet, reportDefinition.getColumnDefinitions(),
                reportDefinition.getDataStartRow());
        List<SectionDTO> sections = sectionSplitter.convertToSections(reportDefinition, sheet, dataRows);
        assertEquals(25, sections.size());
    }

    @Test
    public void shouldSectionBreak() {
        assertTrue(sectionSplitter.isSectionBreak("field1", null));
        assertFalse(sectionSplitter.isSectionBreak("field1", "field2"));
        assertFalse(sectionSplitter.isSectionBreak("", null));
        assertFalse(sectionSplitter.isSectionBreak(null, null));
    }

}
