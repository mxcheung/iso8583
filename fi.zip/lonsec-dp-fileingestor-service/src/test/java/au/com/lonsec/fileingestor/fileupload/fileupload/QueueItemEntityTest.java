package au.com.lonsec.fileingestor.fileupload.fileupload;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.fileupload.QueueItemEntity;

public class QueueItemEntityTest {

    private QueueItemEntity queueItemEntity;

    @Before
    public void setup() {
        queueItemEntity = DomainStereotypeUtil.getQueueItemEntity();
    }

    @Test
    public void verifyEntity() throws JsonProcessingException {
        assertEquals(DomainStereotypeUtil.QUEUE_ITEM_ID, queueItemEntity.getId());
        assertEquals(DomainStereotypeUtil.FILE_ID, queueItemEntity.getFileId());
    }

}
