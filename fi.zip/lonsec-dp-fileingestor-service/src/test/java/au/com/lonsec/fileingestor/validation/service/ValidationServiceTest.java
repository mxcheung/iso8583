package au.com.lonsec.fileingestor.validation.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.fileupload.model.ValidationDTO;
import au.com.lonsec.fileingestor.fileupload.model.ValidationError;
import au.com.lonsec.fileingestor.util.JSONHelper;
import au.com.lonsec.fileingestor.validation.model.ValidationRequest;
import au.com.lonsec.fileingestor.validation.model.ValidationRule;
import au.com.lonsec.fileingestor.validation.server.ValidationService;

public class ValidationServiceTest extends ValidationServiceTst {

	protected static final String GROUP_LEVEL_FILEPATH = "src\\test\\resources\\validation\\ValidationRequest_Group.json";
	protected static final String ROW_LEVEL_FILEPATH = "src\\test\\resources\\validation\\ValidationRequest_Row.json";

	private ObjectMapper mapper;

	private ValidationService validationService;

	List<Map<String, Object>> dataRows;

	@Before
	public void setup() throws Exception {
		validationService = new ValidationService();
		dataRows = DomainStereotypeUtil.getDataRows();
		mapper = JSONHelper.getObjectMapper();
	}

	@Test
	public void shouldValidateHolding() {

		ValidationDTO holding = new ValidationDTO();
		String apirCd = "APIR123456789";
		String securityName = "register-user-defined-functions-spring-expression-language";

		Map<String, Object> data = new HashMap<String, Object>();
		data.put("apirCd", apirCd);
		data.put("securityName", securityName);
		holding.setData(data);

		holding.setData(data);
		List<ValidationRule> validationRules = new ArrayList<ValidationRule>();
		validationRules.add(
				new ValidationRule("#apirCd", "#apirCd.length() <= 9", "'apirCd must be between 0 and 9 characters'"));
		validationRules.add(new ValidationRule("#securityName", "#securityName.length() <= 20 ",
				"'securityName must be between 0 and 20 characters'"));
		List<ValidationError> validationErrors = validationService.validatevalidationDTO(holding, validationRules);

		assertEquals(2, validationErrors.size());

	}

	@Test
	public void shouldValidateGroup() {
		ValidationDTO validationDTO = new ValidationDTO();
		validationDTO.setDataRows(dataRows);
		List<ValidationRule> validationRules = new ArrayList<ValidationRule>();
		String key = "#calcTotal(#dataSet,'absPortfolioWeight')";
		String expression = "(#value gt 100)";
		String message = "'apirCd  must be between 0 and 9 characters'";
		validationRules.add(new ValidationRule(key, expression, message));
		List<ValidationError> validationErrors = validationService.validationGroupItem(validationDTO, validationRules);
		assertEquals(1, validationErrors.size());
	}

	@Test
	public void shouldValidateValidItem() {
		ValidationDTO validationDTO = DomainStereotypeUtil.getValidationDTO();
		ValidationRule validationRule = new ValidationRule("#apirCd", "#apirCd.length() <= 9",
				"'apirCd must be between 0 and 9 characters'");
		Optional<ValidationError> validationError = validationService.validationItem(validationDTO, validationRule);
		assertFalse(validationError.isPresent());
	}

	@Test
	public void shouldValidateValidItemWithError() {
		ValidationDTO validationDTO = DomainStereotypeUtil.getValidationDTO();
		ValidationRule validationRule = new ValidationRule("#apirCd", "#apirCd.length() > 9",
				"'apirCd must be between 0 and 9 characters'");
		Optional<ValidationError> validationError = validationService.validationItem(validationDTO, validationRule);
		assertTrue(validationError.isPresent());
	}
	
	@Test
	public void shouldValidateValidItemWithInvalidExpression() {
		ValidationDTO validationDTO = DomainStereotypeUtil.getValidationDTO();
		ValidationRule validationRule = new ValidationRule("#apirCd", "#apirCd.lexxngth() > 9",
				"'apirCd must be between 0 and 9 characters'");
		Optional<ValidationError> validationError = validationService.validationItem(validationDTO, validationRule);
		assertFalse(validationError.isPresent());
	}
	
	@Test
	public void shouldValidateGroupItem() {
		ValidationDTO validationDTO = new ValidationDTO();
		validationDTO.setDataRows(dataRows);
		List<ValidationRule> validationRules = new ArrayList<ValidationRule>();
		String key = "#calcTotal(#dataSet,'absPortfolioWeight')";
		String expression = "(#value le 100)";
		String message = "'apirCd  must be between 0 and 9 characters'";
		validationRules.add(new ValidationRule(key, expression, message));
		List<ValidationError> validationErrors = validationService.validationGroupItem(validationDTO, validationRules);
		assertEquals(0, validationErrors.size());
	}
	
	@Test
	public void shouldValidateGroupItemWithErro() {
		ValidationDTO validationDTO = new ValidationDTO();
		validationDTO.setDataRows(dataRows);
		List<ValidationRule> validationRules = new ArrayList<ValidationRule>();
		String key = "#calcTotal(#dataSet,'absPortfolioWeight')";
		String expression = "(#value gt 100)";
		String message = "'apirCd  must be between 0 and 9 characters'";
		validationRules.add(new ValidationRule(key, expression, message));
		List<ValidationError> validationErrors = validationService.validationGroupItem(validationDTO, validationRules);
		assertEquals(1, validationErrors.size());
	}
	
	
	
	@Test
	public void shouldValidateGroupItemWithInvalidExpression() {
		ValidationDTO validationDTO = new ValidationDTO();
		validationDTO.setDataRows(dataRows);
		List<ValidationRule> validationRules = new ArrayList<ValidationRule>();
		String key = "#calcxxxxTotal(#dataSet,'absPortfolioWeight')";
		String expression = "(#value gt 100)";
		String message = "'apirCd  must be between 0 and 9 characters'";
		validationRules.add(new ValidationRule(key, expression, message));
		List<ValidationError> validationErrors = validationService.validationGroupItem(validationDTO, validationRules);
		assertEquals(0, validationErrors.size());
	}

	

	@Test
	public void shouldValidateRequestRowLevel() throws IOException {
		String json = getFileSpecJSON(ROW_LEVEL_FILEPATH);
		ValidationRequest validationRequest = mapper.readValue(json, ValidationRequest.class);
		assertNotNull(validationRequest.getValidationDTO().getData());
		List<ValidationError> validationErrors = validationService.validatevalidationDTO(validationRequest);
		assertEquals(4, validationErrors.size());
	}

	@Test
	public void shouldValidateRequestGroupLevel() throws IOException {
		String json = getFileSpecJSON(GROUP_LEVEL_FILEPATH);
		ValidationRequest validationRequest = mapper.readValue(json, ValidationRequest.class);
		assertNull(validationRequest.getValidationDTO().getData());
		assertNotNull(validationRequest.getValidationDTO().getDataRows());
		List<ValidationError> validationErrors = validationService.validatevalidationDTO(validationRequest);
		assertEquals(2, validationErrors.size());
	}

}
