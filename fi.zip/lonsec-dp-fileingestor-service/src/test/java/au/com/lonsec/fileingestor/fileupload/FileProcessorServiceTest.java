package au.com.lonsec.fileingestor.fileupload;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.io.IOUtils;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.ss.usermodel.Sheet;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.filespec.FileSpecConfig;
import au.com.lonsec.fileingestor.filespec.FileSpecService;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.fileupload.model.DataSetDTO;
import au.com.lonsec.fileingestor.fileupload.model.ResultDTO;
import au.com.lonsec.fileingestor.fileupload.validator.SheetConfig;
import au.com.lonsec.fileingestor.fileupload.validator.SheetValidator;
import au.com.lonsec.fileingestor.poi.PoiService;

@RunWith(MockitoJUnitRunner.class)
public class FileProcessorServiceTest {

    private static final String ORIG_FILENAME = DomainStereotypeUtil.ORIGINAL_FILE_NAME;

    private static final String FILE_SPEC_DUMMY = "DUMMY";

    private FileProcessorService fileProcessorService;

    private static final String XSSF_RESOURCE = "/xssf/test/FileSpecMap_gaps.xls";

    private static final String XSSF_MISSING_MAP_RESOURCE = "/xssf/test/MissingMapWith_gaps.xls";

    @Mock
    FileSpecConfig config;

    @Mock
    PoiService mockPoiService;

    @Mock
    private FileSpecService fileSpecService;

    @Mock
    private ReportDefinition mockReportDefinition;

    @Mock
    private MultipartFile mockMultipartFile;

    @Mock
    private Map<String, Sheet> sheetMap;

    @Mock
    private SheetValidator sheetValidator;

    @Mock
    private SheetConfig sheetConfig;

    @Mock
    private FileService fileService;

    @Mock
    private QueueRepository queueRepository;

    private ReportDefinition reportDefinition;

    private InputStream excelFileToRead = getClass().getResourceAsStream(XSSF_RESOURCE);

    private List<Sheet> wbData;

    private PoiService poiService;

    @Before
    public void setup() throws IOException {
        fileProcessorService = new FileProcessorService(mockPoiService, sheetValidator, sheetConfig, fileService,
                queueRepository);
        when(fileSpecService.getReportDefinition(FILE_SPEC_DUMMY)).thenReturn(mockReportDefinition);
        when(mockMultipartFile.getOriginalFilename()).thenReturn(ORIG_FILENAME);
    }

    @Test
    public void shouldImportData() throws IOException, OpenXML4JException {

        when(mockPoiService.extractSheets(excelFileToRead, FILE_SPEC_DUMMY)).thenReturn(wbData);
        ResultDTO result = fileProcessorService.importData(mockMultipartFile, FILE_SPEC_DUMMY);
        assertNotNull(result);
        assertEquals(0, result.getTotalDatasets());
        assertEquals(ORIG_FILENAME, result.getFileName());
    }

    @Test
    public void shouldImportDataFromInputStream()
            throws IOException, OpenXML4JException, MappingSheetNotFoundException, FileSpecNotFoundException {
        excelFileToRead = getClass().getResourceAsStream(XSSF_RESOURCE);
        poiService = new PoiService();
        List<Sheet> wbData = poiService.extractSheets(excelFileToRead, "xls");
        when(mockPoiService.extractSheets(any(), any(String.class))).thenReturn(wbData);
        ResultDTO result = fileProcessorService.importData(excelFileToRead, ORIG_FILENAME);
        assertEquals(ORIG_FILENAME, result.getFileName());
    }

    @Test
    public void shouldProcessQItem() throws JsonParseException, JsonMappingException, IOException {
        QueueItemEntity queueItemEntity = new QueueItemEntity();
        Long fileId = 1L;
        queueItemEntity.setFileId(fileId);
        FileEntity fileEntity = DomainStereotypeUtil.getFileEntity();

        when(fileService.fetchFileEntity(fileId)).thenReturn(fileEntity);
        fileProcessorService.processQItem(queueItemEntity);
    }

    @Test
    public void shouldProcessItem()
            throws IOException, OpenXML4JException, MappingSheetNotFoundException, FileSpecNotFoundException {
        List<QueueItemEntity> items = new ArrayList<QueueItemEntity>();
        QueueItemEntity queueItemEntity = new QueueItemEntity();
        Long fileId = 1L;
        queueItemEntity.setFileId(fileId);
        items.add(queueItemEntity);
        excelFileToRead = getClass().getResourceAsStream(XSSF_RESOURCE);
        poiService = new PoiService();
        List<Sheet> wbData = poiService.extractSheets(excelFileToRead, "xls");
        when(mockPoiService.extractSheets(any(), any(String.class))).thenReturn(wbData);

        FileEntity fileEntity = DomainStereotypeUtil.getFileEntity();
        when(fileService.fetchFileEntity(fileId)).thenReturn(fileEntity);

        FileEntity result = fileProcessorService.processItem(queueItemEntity);
        assertEquals(ORIG_FILENAME, result.getOriginalFileName());
    }

    @Test
    public void shouldGetReportDefinition()
            throws InvalidFormatException, IOException, FileSpecNotFoundException, MappingSheetNotFoundException {
        poiService = new PoiService();
        excelFileToRead = getClass().getResourceAsStream(XSSF_RESOURCE);
        List<Sheet> wbData = poiService.extractSheets(excelFileToRead, "xls");
        ReportDefinition reportDefinition = DomainStereotypeUtil.getReportDefinition();
        Optional<Sheet> ms = fileProcessorService.filterByName(wbData, "MAPPING");
        when(sheetConfig.getReportDefinition(ms.get())).thenReturn(reportDefinition);
        ReportDefinition actual = fileProcessorService.getReportDefinition(ORIG_FILENAME, wbData);
        assertEquals(2, actual.getDataStartRow());
    }

    @Test(expected = MappingSheetNotFoundException.class)
    public void shouldRaiseExceptionOnMissingMappingSheet()
            throws InvalidFormatException, IOException, FileSpecNotFoundException, MappingSheetNotFoundException {
        poiService = new PoiService();
        excelFileToRead = getClass().getResourceAsStream(XSSF_MISSING_MAP_RESOURCE);
        List<Sheet> wbData = poiService.extractSheets(excelFileToRead, "xls");
        ReportDefinition actual = fileProcessorService.getReportDefinition(ORIG_FILENAME, wbData);
        assertEquals(2, actual.getDataStartRow());
    }

    @Test
    public void shouldExtractDataSet() throws IOException, OpenXML4JException {
        poiService = new PoiService();
        List<Sheet> wbData = poiService.extractSheets(excelFileToRead, "xls");
        assertEquals(4, wbData.size());
        reportDefinition = DomainStereotypeUtil.getReportDefinition();
        List<DataSetDTO> result = fileProcessorService.extractDataSets(reportDefinition, wbData);
        assertEquals(0, result.size());
    }

    @Test
    public void shouldGenerateResult() throws IOException, OpenXML4JException {
        List<DataSetDTO> dataSets = DomainStereotypeUtil.getDataSets();
        ResultDTO result = fileProcessorService.generateResult(ORIG_FILENAME, dataSets);
        assertNotNull(result);
        assertEquals(1, result.getTotalDatasets());
        assertEquals(0, result.getErrorDatasets());
        assertEquals(ORIG_FILENAME, result.getFileName());
        DataSetDTO dataSet = DomainStereotypeUtil.getDataSetDTO();
        dataSet.setContainsErrors(true);
        dataSets.add(dataSet);
        result = fileProcessorService.generateResult(ORIG_FILENAME, dataSets);
        assertEquals(2, result.getTotalDatasets());
        assertEquals(1, result.getErrorDatasets());
    }

    @Test
    public void shouldOverrideMappings() throws IOException, OpenXML4JException {
        PoiService poiService = new PoiService();
        reportDefinition = DomainStereotypeUtil.getReportDefinition();
        wbData = poiService.extractSheets(excelFileToRead, "xls");
        Optional<Sheet> mappingSheet = fileProcessorService.overrideMapppings(reportDefinition, wbData);
        assertTrue(mappingSheet.isPresent());
    }

    @Test
    public void shouldSkipOverrideMappings() throws IOException, OpenXML4JException {
        reportDefinition = DomainStereotypeUtil.getReportDefinition();
        List<Sheet> sheets = new ArrayList<Sheet>();
        Optional<Sheet> mappingSheet = fileProcessorService.overrideMapppings(reportDefinition, sheets);
        assertFalse(mappingSheet.isPresent());
    }

    @Test
    public void shouldSaveResult() throws IOException, OpenXML4JException {
        FileEntity fileEntity = DomainStereotypeUtil.getFileEntity();
        QueueItemEntity queueItemEntity = DomainStereotypeUtil.getQueueItemEntity();
        ;
        fileProcessorService.saveResult(queueItemEntity, fileEntity);
        assertEquals(fileEntity, fileProcessorService.getLastProcessedFileEntity());
    }

    @Test
    public void shouldSaveResults() throws IOException, OpenXML4JException {
        FileContentEntity fileContent = DomainStereotypeUtil.getFileContentEntity();
        ResultDTO resultDTO = DomainStereotypeUtil.getResultDTO();
        fileContent.setResultContent(null);
        assertNull(fileContent.getResultContent());
        FileContentEntity result = fileProcessorService.saveResults(fileContent, resultDTO);
        assertNotNull(result.getResultContent());
    }

    @Test
    public void shouldGetFileContents() throws IOException, OpenXML4JException {
        FileContentEntity fileContent = DomainStereotypeUtil.getFileContentEntity();
        fileContent.setResultContent(null);
        assertNull(fileContent.getResultContent());
        InputStream result = fileProcessorService.getFileContents(fileContent);
        String fileContents = IOUtils.toString(result, StandardCharsets.UTF_8.name());
        assertNotNull(result);
        assertEquals(DomainStereotypeUtil.FILE_CONTENTS, fileContents);

    }

}
