package au.com.lonsec.fileingestor.fileupload.fileupload;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.fileupload.FileContentEntity;

public class FileContentEntityTest {

    private FileContentEntity fileContentEntity;

    @Before
    public void setup() {
        fileContentEntity = DomainStereotypeUtil.getFileContentEntity();
    }

    @Test
    public void verifyEntity() throws JsonProcessingException {
        assertEquals(1L, fileContentEntity.getId().longValue());
        assertEquals(DomainStereotypeUtil.FILE_CONTENTS_ZIP, fileContentEntity.getFileContent());
        assertEquals(DomainStereotypeUtil.RESULT_CONTENTS, fileContentEntity.getResultContent());
    }

}
