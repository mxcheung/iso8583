package au.com.lonsec.fileingestor.fileupload.validator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Sheet;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.filespec.FileSpecConfig;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.fileupload.model.DataSetDTO;
import au.com.lonsec.fileingestor.fileupload.model.SectionDTO;
import au.com.lonsec.fileingestor.fileupload.model.ValidationDTO;
import au.com.lonsec.fileingestor.poi.PoiService;
import au.com.lonsec.fileingestor.validation.server.ValidationService;

@RunWith(MockitoJUnitRunner.class)
public class SectionValidatorTest {

	private SectionValidator sectionValidator;

	@Mock
	FileSpecConfig config;

	@Mock
	private GroupValidator groupValidator;

	@Mock
	private RowValidator rowValidator;

	@Mock
	private PoiService poiService;

	@Mock
	private Sheet sheet;
	
	@Mock
	ValidationService validationService;

	private Map<String, String> filespecs;

	private ReportDefinition reportDefinition;

	private List<ValidationDTO> validationDTOs;

	private ValidationDTO validationDTO;
	
	private ValidationDTO validationGroupDTO;

	@Before
	public void setup() {
		filespecs = new HashMap<String, String>();
		filespecs.put("portfolioHoldingDef", "filespec/portfolioHoldingDef.json");
		when(config.getFilespecs()).thenReturn(filespecs);
		sectionValidator = new SectionValidator(groupValidator, rowValidator);
		reportDefinition = DomainStereotypeUtil.getReportDefinition();
		validationDTOs = DomainStereotypeUtil.getValidationDTOs();
		validationDTO = DomainStereotypeUtil.getValidationDTO();
		validationGroupDTO = DomainStereotypeUtil.getValidationDTO();
		validationGroupDTO.setGroupName("GroupValidation");
	}

	@Test
	public void shouldValidate() {
		SectionDTO sectionDTO = DomainStereotypeUtil.getSectionDTO();
		List<Map<String, Object>> dataRows = sectionDTO.getDataRows();
		validationGroupDTO.setDataRows(dataRows);
		when(groupValidator.validateGroupData(any(ReportDefinition.class),any( ValidationDTO.class))).thenReturn(validationGroupDTO);
		DataSetDTO dataSetDTO = sectionValidator.validateSection(reportDefinition, sectionDTO);
		assertEquals(2, validationDTOs.size());
		assertFalse(dataSetDTO.isContainsErrors());
	}

	@Test
	public void shouldGenerateDataSet() {
		SectionDTO sectionDTO = DomainStereotypeUtil.getSectionDTO();
		List<Map<String, Object>> dataRows = sectionDTO.getDataRows();
		validationGroupDTO.setDataRows(dataRows);
		when(groupValidator.validateGroupData(reportDefinition, validationGroupDTO)).thenReturn(validationDTO);
		ValidationDTO groupvalidationDTO = DomainStereotypeUtil.getValidationDTO();
		DataSetDTO dataSetDTO = sectionValidator.generateDataSet(sectionDTO, validationDTOs, groupvalidationDTO);
		assertEquals(2, dataSetDTO.getTotalRows());
		assertFalse(dataSetDTO.isContainsErrors());
	}

	@Test
	public void shouldGenerateDataSetWithGroupError() {
		SectionDTO sectionDTO = DomainStereotypeUtil.getSectionDTO();
		List<Map<String, Object>> dataRows = sectionDTO.getDataRows();
		validationGroupDTO.setDataRows(dataRows);
		when(groupValidator.validateGroupData(reportDefinition, validationGroupDTO)).thenReturn(validationDTO);
		ValidationDTO groupvalidationDTO = DomainStereotypeUtil.getValidationDTO();
		groupvalidationDTO.setContainsErrors(true);
		DataSetDTO dataSetDTO = sectionValidator.generateDataSet(sectionDTO, validationDTOs, groupvalidationDTO);
		assertEquals(2, dataSetDTO.getTotalRows());
		assertTrue(dataSetDTO.isContainsErrors());
	}

}
