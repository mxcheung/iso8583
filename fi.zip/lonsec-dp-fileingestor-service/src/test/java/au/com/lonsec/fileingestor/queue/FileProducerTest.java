package au.com.lonsec.fileingestor.queue;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import au.com.lonsec.fileingestor.fileupload.FileIngestorService;
import au.com.lonsec.fileingestor.fileupload.QueueItemEntity;
import au.com.lonsec.fileingestor.fileupload.QueueRepository;

@RunWith(MockitoJUnitRunner.class)
public class FileProducerTest {

    @Mock
    private FileIngestorService fileIngestorService;

    @Mock
    QueueRepository queueRepository;

    @Mock
    FileIngestorQueueService fileIngestorQueueService;

    private FileProducer fileProducer;

    @Before
    public void setup() throws InterruptedException {
        fileProducer = new FileProducer(queueRepository, fileIngestorQueueService);
    }

    @Test
    public void shouldRecoverJobs() throws InterruptedException {
        List<QueueItemEntity> items = new ArrayList<QueueItemEntity>();
        QueueItemEntity queueItemEntity = new QueueItemEntity();
        Long fileId = 1L;
        queueItemEntity.setFileId(fileId);
        items.add(queueItemEntity);
        when(queueRepository.findAll()).thenReturn(items);
        fileProducer.recoverJobs();
        verify(queueRepository, times(1)).findAll();
        verifyNoMoreInteractions(queueRepository);
    }

    @Test
    public void shouldEnqueueJob() throws InterruptedException {
        List<QueueItemEntity> items = new ArrayList<QueueItemEntity>();
        QueueItemEntity queueItemEntity = new QueueItemEntity();
        Long fileId = 1L;
        queueItemEntity.setFileId(fileId);
        items.add(queueItemEntity);
        when(queueRepository.findAll()).thenReturn(items);
        fileProducer.put(queueItemEntity);
        verify(queueRepository, times(1)).save(queueItemEntity);
        verifyNoMoreInteractions(queueRepository);
    }

}
