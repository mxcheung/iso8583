package au.com.lonsec.fileingestor.fileupload.model;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.List;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class SectionDTOTest extends DataSetDTOTst {

	private final static String JSON_STRING = "{\"sheetName\":null,\"sectionName\":\"sectionName\",\"dataRows\":[{\"securityName\":\"BOOZ ALLEN\",\"relPortfolioWeight\":\"0.45\",\"apirCd\":\"apirCd123\",\"absPortfolioWeight\":\"0.12\"}],\"validationDTOs\":[{\"rowNum\":1,\"data\":{\"securityName\":\"BOOZ ALLEN\",\"apirCd\":\"apirCd123\",\"absPortfolioWeight\":\"67\"},\"containsErrors\":false},{\"rowNum\":1,\"data\":{\"securityName\":\"BOOZ ALLEN\",\"apirCd\":\"apirCd123\",\"absPortfolioWeight\":\"67\"},\"containsErrors\":false}]}";

	private ObjectMapper mapper;

	@Before
	public void setup() {
		mapper = new ObjectMapper();
		sectionDTO = getSectionDTO();
	}

	@Test
	public void shouldSerialize() throws JsonProcessingException {
		String json = this.mapper.writeValueAsString(sectionDTO);
		assertEquals(JSON_STRING, json);
	}

	@Test
	public void shouldDeserialize() throws JSONException, JsonParseException, JsonMappingException, IOException {
		sectionDTO = mapper.readValue(JSON_STRING, SectionDTO.class);
		List<ValidationDTO> data = sectionDTO.getValidationDTOs();
		assertEquals(2, data.size());
		assertEquals("sectionName", sectionDTO.getSectionName());
	}

}
