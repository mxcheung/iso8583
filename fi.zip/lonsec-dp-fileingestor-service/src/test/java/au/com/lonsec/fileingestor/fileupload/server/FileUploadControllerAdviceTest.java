package au.com.lonsec.fileingestor.fileupload.server;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;



public class FileUploadControllerAdviceTest {
	
	
	private FileUploadControllerAdvice fileUploadControllerAdvice ;
	
	@Before
	public void setup() {
		fileUploadControllerAdvice = new FileUploadControllerAdvice();

	}

    @Test
    public void testhandleBadRequest()  {
    	Exception badRequestException = new Exception("Bad Request");
    	ResponseEntity<String> response = fileUploadControllerAdvice.handleBadRequest(badRequestException);
    	assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }
    
    @Test
    public void testhandleException()  {
    	Exception badRequestException = new Exception("Bad Request");
    	ResponseEntity<String> response = fileUploadControllerAdvice.handleException(badRequestException);
    	assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }
    
}
