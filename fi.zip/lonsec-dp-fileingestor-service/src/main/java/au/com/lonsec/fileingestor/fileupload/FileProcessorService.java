package au.com.lonsec.fileingestor.fileupload;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.ss.usermodel.Sheet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.spel.SpelParseException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.fileupload.model.DataSetDTO;
import au.com.lonsec.fileingestor.fileupload.model.ResultDTO;
import au.com.lonsec.fileingestor.fileupload.validator.SheetConfig;
import au.com.lonsec.fileingestor.fileupload.validator.SheetValidator;
import au.com.lonsec.fileingestor.poi.PoiService;
import au.com.lonsec.fileingestor.util.FileUtil;
import au.com.lonsec.fileingestor.util.JSONHelper;

@Service
public class FileProcessorService {

    private static final String MAPPING = "MAPPING";

    private static final String FAILED = "FAILED";

    private static final String PROCESSED = "PROCESSED";

    private static final Logger LOGGER = LoggerFactory.getLogger(FileProcessorService.class);

    private final PoiService poiService;

    private final SheetValidator sheetValidator;

    private final SheetConfig sheetConfig;

    private ObjectMapper mapper;

    private final FileService fileService;
    
    private final QueueRepository queueRepository;
    
    private FileEntity lastProcessedFileEntity;


    @Autowired
    FileProcessorService(PoiService poiService, SheetValidator sheetValidator, SheetConfig sheetConfig,
            FileService fileService, QueueRepository queueRepository) {
        this.poiService = poiService;
        this.sheetValidator = sheetValidator;
        this.sheetConfig = sheetConfig;
        this.fileService = fileService;
        this.queueRepository = queueRepository;
        mapper = JSONHelper.getObjectMapper();
    }

    /**
     * @param multipartFile
     *            Excel file to upload.
     * @param fileSpec
     *            File upload spec.
     * @return File upload summary.
     * @throws IOException
     *             Error reading input stream.
     * @throws OpenXML4JException
     *             File format exception.
     */
    public ResultDTO importData(MultipartFile multipartFile, String fileSpec) throws IOException, OpenXML4JException {
        ReportDefinition reportDefinition = sheetConfig.getReportDefinition(fileSpec);
        InputStream is = multipartFile.getInputStream();
        String originalFileName = multipartFile.getOriginalFilename();
        String ext = FilenameUtils.getExtension(originalFileName);
        List<DataSetDTO> dataSets = processSheets(reportDefinition, poiService.extractSheets(is, ext));
        ResultDTO result = generateResult(originalFileName, dataSets);
        return result;
    }

    public ResultDTO importData(InputStream is, String originalFileName)
            throws IOException, OpenXML4JException, MappingSheetNotFoundException, FileSpecNotFoundException {

        LOGGER.info("importData {}", originalFileName);
        String ext = FilenameUtils.getExtension(originalFileName);
        List<Sheet> sheets = poiService.extractSheets(is, ext);
        ReportDefinition reportDefinition = getReportDefinition(originalFileName, sheets);

        List<DataSetDTO> dataSets = processSheets(reportDefinition, sheets);

        ResultDTO result = generateResult(originalFileName, dataSets);
        return result;
    }

    public ReportDefinition getReportDefinition(String originalFileName, List<Sheet> sheets)
            throws IOException, MappingSheetNotFoundException, FileSpecNotFoundException {
        Optional<Sheet> mappingSheet = filterByName(sheets, MAPPING);
        if (mappingSheet.isPresent()) {
            return sheetConfig.getReportDefinition(mappingSheet.get());
        } else {
            throw new MappingSheetNotFoundException("Unable to locate mapping sheet");
        }
    }

    public List<DataSetDTO> processSheets(ReportDefinition reportDefinition, List<Sheet> sheets) {
        overrideMapppings(reportDefinition, sheets);
        return extractDataSets(reportDefinition, sheets);
    }

    /**
     * @param reportDefinition
     *            Definition of the file to ingest.
     * @param sheets
     *            Sheets in the workbook.
     * @return List of result set.
     */
    public List<DataSetDTO> extractDataSets(ReportDefinition reportDefinition, List<Sheet> sheets) {
        List<DataSetDTO> dataSets = new ArrayList<DataSetDTO>();
        for (Sheet sheet : sheets) {
            List<DataSetDTO> dataSetDTOs = sheetValidator.validateSheet(reportDefinition, sheet);
            dataSets.addAll(dataSetDTOs);
        }
        return dataSets;
    }

    public Optional<Sheet> overrideMapppings(ReportDefinition reportDefinition, List<Sheet> sheets) {
        Optional<Sheet> mappingSheet = filterByName(sheets, MAPPING);
        mappingSheet.ifPresent(ms -> sheetConfig.loadConfig(reportDefinition, ms));
        return mappingSheet;
    }

    public Optional<Sheet> filterByName(List<Sheet> sheets, String name) {
        return sheets.stream().filter(sheet -> StringUtils.equalsIgnoreCase(sheet.getSheetName(), name)).findFirst();
    }

    /**
     * @param fileName
     *            - Name of file ingested.
     * @param dataSets
     *            Data sets ingested within the file.
     * @return File ingest summary.
     */
    public ResultDTO generateResult(String fileName, List<DataSetDTO> dataSets) {
        List<DataSetDTO> dataSetsWithError = dataSets.stream().filter(item -> item.isContainsErrors())
                .collect(Collectors.toList());
        ResultDTO result = new ResultDTO();
        result.setFileName(fileName);
        result.setTotalDatasets(dataSets.size());
        result.setErrorDatasets(dataSetsWithError.size());
        result.setDataSets(dataSets);
        return result;
    }


    
    @Transactional
    public void processQItem(QueueItemEntity item) {
        FileEntity fileEntity = processItem(item);
        saveResult(item, fileEntity);
    }
    
    @Transactional
    public void saveResult(QueueItemEntity item, FileEntity fileEntity) {
        if (fileEntity != null) {
            fileService.save(fileEntity);
            setLastProcessedFileEntity(fileEntity);
        }
        queueRepository.delete(item);
    }



    public FileEntity processItem(QueueItemEntity item) {
        Long fileId = item.getFileId();
        LOGGER.info("Processing {}", fileId);
        FileEntity fileEntity = fileService.fetchFileEntity(fileId);
        if (fileEntity != null) {
            try {
                String origFileName = fileEntity.getOriginalFileName();
                FileContentEntity fileContent = fileEntity.getFileContentEntity();
                InputStream inputStream = getFileContents(fileContent);
                ResultDTO result = importData(inputStream, origFileName);
                saveResults(fileContent, result);
                fileEntity.setTotalDatasets(result.getTotalDatasets());
                fileEntity.setErrorDatasets(result.getErrorDatasets());
                fileEntity.setStatus(PROCESSED);
            } catch (SpelParseException e) {
                fileEntity.setStatus(FAILED);
                fileEntity.setFailReason(e.getMessage());
                LOGGER.error("Validation Rule exception occurred {}", e);
            } catch (OpenXML4JException e) {
                fileEntity.setStatus(FAILED);
                fileEntity.setFailReason(e.getMessage());
                LOGGER.error("OpenXML4JException exception occurred {}", e);
            } catch (MappingSheetNotFoundException e) {
                fileEntity.setStatus(FAILED);
                fileEntity.setFailReason(e.getMessage());
                LOGGER.error("MappingSheetNotFoundException occurred {}", e);
            } catch (FileSpecNotFoundException e) {
                LOGGER.error("FileSpecNotFoundException occurred {}", e);
                fileEntity.setStatus(FAILED);
                fileEntity.setFailReason(e.getMessage());
            } catch (Exception e) {
                fileEntity.setStatus(FAILED);
                fileEntity.setFailReason(e.toString());
                LOGGER.error("Unexpected exception occurred {}", e);
            }
        }
        return fileEntity;
    }

    public FileContentEntity saveResults(FileContentEntity fileContent, ResultDTO result)
            throws JsonProcessingException {
        String json = mapper.writeValueAsString(result);
        fileContent.setResultContent(FileUtil.gzipCompress(json.getBytes()));
        return fileContent;
    }

    public InputStream getFileContents(FileContentEntity fileContent) throws IOException {
        byte[] compressedData = fileContent.getFileContent();
        byte[] uncompressedData = FileUtil.gzipUncompress(compressedData);
        InputStream inputStream = new ByteArrayInputStream(uncompressedData);
        return inputStream;
    }

    public FileEntity getLastProcessedFileEntity() {
        return lastProcessedFileEntity;
    }

    public void setLastProcessedFileEntity(FileEntity lastProcessedFileEntity) {
        this.lastProcessedFileEntity = lastProcessedFileEntity;
    }
    
    

}