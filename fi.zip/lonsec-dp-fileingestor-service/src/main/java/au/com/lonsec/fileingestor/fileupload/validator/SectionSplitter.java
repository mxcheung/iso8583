package au.com.lonsec.fileingestor.fileupload.validator;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Service;

import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.fileupload.model.SectionDTO;
import au.com.lonsec.fileingestor.validation.model.ValidationRule;
import au.com.lonsec.fileingestor.validation.util.SpelUtil;

@Service
public class SectionSplitter {

    private static final String APIR_CD = "apirCd";
    private static final String FUND_NAME = "fundName";

    public List<SectionDTO> convertToSections(ReportDefinition reportDefinition, Sheet sheet, List<Map<String, Object>> dataRows) {

        List<ValidationRule> sectionRules = reportDefinition.getSectionValidationRules();
        List<SectionDTO> sections = new ArrayList<SectionDTO>();

        if (sectionRules != null) {
            List<Map<String, Object>> sectionRows = new ArrayList<Map<String, Object>>();
            for (Map<String, Object> dataRow : dataRows) {
                if (isSectionBreak(SpelUtil.resolveObjectToString(dataRow.get(APIR_CD)), SpelUtil.resolveObjectToString(dataRow.get(FUND_NAME)))) {
                    sectionRows = new ArrayList<Map<String, Object>>();
                    String sectionKey = APIR_CD;
                    String sectionName = (String) dataRow.get(sectionKey);
                    SectionDTO sectionDTO = new SectionDTO();
                    sectionDTO.setSheetName(sheet.getSheetName());
                    sectionDTO.setSectionName(sectionName);
                    sectionDTO.setDataRows(sectionRows);
                    sections.add(sectionDTO);
                }

                sectionRows.add(dataRow);
            }
        } else {
            SectionDTO sectionDTO = new SectionDTO();
            sectionDTO.setSheetName(sheet.getSheetName());
            sectionDTO.setDataRows(dataRows);
            sections.add(sectionDTO);
        }
        return sections;
    }

    public boolean isSectionBreak(String field1, String field2) {
        return (!StringUtils.isEmpty(field1) && (field2 == null));
    }

}
