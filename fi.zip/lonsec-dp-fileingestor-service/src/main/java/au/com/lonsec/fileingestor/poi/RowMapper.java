package au.com.lonsec.fileingestor.poi;

import java.util.HashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;

import au.com.lonsec.fileingestor.filespec.model.ColumnDefinition;
import au.com.lonsec.fileingestor.validation.util.SpelUtil;

public class RowMapper {

    public RowMapper() {
        super();
    }

    public HashMap<String, Object> rowToMap(List<ColumnDefinition> headers, Row row) {
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        dataMap.put("rowNum", row.getRowNum());
        for (ColumnDefinition header : headers) {
            String coName = header.getTargetName();
            int idx = header.getColumnIdx();
            Cell cell = row.getCell(idx);
            if (cell != null) {
                Object cellValue = getCellValue(cell);
                dataMap.put(coName, cellValue);
            }
        }
        return dataMap;
    }

    public Object getCellValue(Cell cell) {
        if (cell != null) {
            return getCellValue(cell, cell.getCellTypeEnum());
        }
        return null;
    }

    public String getCellRangeText(List<Cell> cells) {
        String cellText = "";
        for (Cell cell : cells) {
            Object cellValue = getCellValue(cell);
            String cellValueStr = SpelUtil.resolveObjectToString(cellValue);
            cellText = cellText + cellValueStr;
        }
        return cellText;
    }

    public Object getCellValue(Cell cell, CellType cellType) {
        Object val = null;
        if (cell != null) {
            switch (cellType) {
            case BOOLEAN:
                val = cell.getBooleanCellValue();
                break;
            case NUMERIC:
                val = cell.getNumericCellValue();
                break;
            case STRING:
                val = cell.getStringCellValue();
                break;
            case ERROR:
                val = cell.getErrorCellValue();
                break;
            case FORMULA:
                val = getCellFormulaValue(cell);
            case BLANK:
            default:
                break;
            }
        }

        return val;
    }

    public Object getCellFormulaValue(Cell cell) {
        Object val = null;
        if (cell != null) {
            switch (cell.getCachedFormulaResultTypeEnum()) {
            case BOOLEAN:
                val = cell.getBooleanCellValue();
                break;
            case NUMERIC:
                val = cell.getNumericCellValue();
                break;
            case STRING:
                val = cell.getStringCellValue();
                break;
            case ERROR:
                val = cell.getErrorCellValue();
                break;
            default:
                break;
            }
        }

        return val;
    }

    public boolean isRowEmpty(Row row) {
        for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
            Cell cell = row.getCell(c);
            if (cell != null && cell.getCellTypeEnum() != CellType.BLANK) {
                return false;
            }
        }
        return true;
    }
    
    /*
     *     Excel displays as  6 but returns as Double 6.0     
     */
    public int getIntValue(Object value) {
        return (int) Double.parseDouble(value.toString());
    }

}