package au.com.lonsec.fileingestor.fileupload.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "dataSetName", "sectionName", "totalRows", "errorRows", "dataRows" })
public class DataSetDTO {

    private String dataSetName;

    private String sectionName;

    private List<ValidationDTO> dataRows;

    private int errorRows;

    private int totalRows;

    private boolean containsErrors;

    public List<ValidationDTO> getDataRows() {
        return dataRows;
    }

    public void setDataRows(List<ValidationDTO> dataRows) {
        this.dataRows = dataRows;
    }

    public String getDataSetName() {
        return dataSetName;
    }

    public void setDataSetName(String dataSetName) {
        this.dataSetName = dataSetName;
    }

    public int getErrorRows() {
        return errorRows;
    }

    public void setErrorRows(int errorRows) {
        this.errorRows = errorRows;
    }

    public int getTotalRows() {
        return totalRows;
    }

    public void setTotalRows(int totalRows) {
        this.totalRows = totalRows;
    }

    public boolean isContainsErrors() {
        return containsErrors;
    }

    public void setContainsErrors(boolean containsErrors) {
        this.containsErrors = containsErrors;
    }

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

}
