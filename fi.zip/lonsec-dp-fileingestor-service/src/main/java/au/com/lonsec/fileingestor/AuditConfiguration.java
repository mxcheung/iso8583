package au.com.lonsec.fileingestor;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

/**
 * AuditConfiguration - supports auditing of entities. @CreatedDate, @LastModifiedDate
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@Configuration
@EnableJpaAuditing
public class AuditConfiguration {
}