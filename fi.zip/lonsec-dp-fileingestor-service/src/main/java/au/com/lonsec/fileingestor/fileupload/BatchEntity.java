package au.com.lonsec.fileingestor.fileupload;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import au.com.lonsec.fileingestor.base.AbstractEntity;

/**
 * Batch Model representation for Batch entity.
 * 
 * @author MCheung
 */

@Entity
@Table(name = "batchitem")
public class BatchEntity extends AbstractEntity {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "id", updatable = false, nullable = false)
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

}
