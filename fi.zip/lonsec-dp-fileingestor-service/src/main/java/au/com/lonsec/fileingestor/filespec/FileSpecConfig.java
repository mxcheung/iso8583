package au.com.lonsec.fileingestor.filespec;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * FileSpecConfig contains a map of available file upload specifications.
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@ConfigurationProperties(prefix = "fileupload")
@Component
public class FileSpecConfig {

    private Map<String, String> filespecs;

    public Map<String, String> getFilespecs() {
        return filespecs;
    }

    public void setFilespecs(Map<String, String> filespecs) {
        this.filespecs = filespecs;
    }

}