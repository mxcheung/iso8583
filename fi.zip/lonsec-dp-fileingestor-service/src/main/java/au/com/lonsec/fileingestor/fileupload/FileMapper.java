package au.com.lonsec.fileingestor.fileupload;

import org.springframework.stereotype.Service;

import au.com.lonsec.fileingestor.fileupload.model.FileDTO;

/**
 * FileMapper supports mapping. 
 *     1. entity to model 
 *     2. model to entity
 * 
 * @author Max Cheung <max.cheung@lonsec.com.au>
 */

@Service
public class FileMapper {

    FileMapper() {
    }


    public FileDTO map(FileEntity source, FileDTO dest) {
        FileDTO fileDTO = new FileDTO();
        fileDTO.setFailReason(source.getFailReason());
        fileDTO.setStatus(source.getStatus());
        fileDTO.setOriginalFileName(source.getOriginalFileName());
        fileDTO.setErrorDatasets(source.getErrorDatasets());
        fileDTO.setTotalDatasets(source.getErrorDatasets());
        fileDTO.setId(source.getId());
        return fileDTO;
    }



}
