package au.com.lonsec.fileingestor.fileupload;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import au.com.lonsec.fileingestor.fileexport.model.ExportFileDTO;
import au.com.lonsec.fileingestor.fileexport.model.ExportQuestionnaireDTO;
import au.com.lonsec.fileingestor.fileexport.model.QuestionnaireDTO;
import au.com.lonsec.fileingestor.queue.FileProducer;
import au.com.lonsec.fileingestor.util.FileUtil;

@Service
public class FileExportService {

    private static final Logger LOGGER = LoggerFactory.getLogger(FileExportService.class);

    private final FileService fileService;

    private final FileContentRepository fileContentRepository;

    private final BatchRepository batchRepository;

    private final FileMapper fileMapper;

    private final FileProducer fileProducer;

    @Autowired
    public FileExportService(FileMapper fileMapper, BatchRepository batchRepository, FileProducer fileProducer,
            FileService fileService, FileContentRepository fileContentRepository) {
        this.fileMapper = fileMapper;
        this.fileProducer = fileProducer;
        this.batchRepository = batchRepository;
        this.fileService = fileService;
        this.fileContentRepository = fileContentRepository;
    }

    @Transactional
    public byte[] exportFiles(ExportQuestionnaireDTO exportRequest) {
        byte[] finalBytes = null;
        try {
            LOGGER.info("---Creating zip file");
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ZipOutputStream zos = new ZipOutputStream(baos);
            List<QuestionnaireDTO> questionnaires = exportRequest.getQuestionnaires();
            for (QuestionnaireDTO questionnaire : questionnaires) {
                List<ExportFileDTO> files = questionnaire.getFiles();
                for (ExportFileDTO exportFileDTO : files) {
                    List<Long> batchIds = exportFileDTO.getBatchIds();
                    List<FileEntity> fileEntities = fileService.findByBatchIds(batchIds);
                    writeZipFile(zos, questionnaire.getQuestionnaireName(), exportFileDTO.getQuestionId(),
                            fileEntities);
                }
            }
            zos.close();
            baos.close();
            finalBytes = baos.toByteArray();
            LOGGER.info("---Done");
        } catch (IOException e) {
            LOGGER.error("Exception occuring export files", e);
        }

        return finalBytes;
    }

    public ZipOutputStream writeZipFile(ZipOutputStream zos, String qfolder, String questionId,
            List<FileEntity> fileEntities) {
        try {
            for (FileEntity fileEntity : fileEntities) {
                addToZip(qfolder, questionId, fileEntity, zos);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return zos;
    }

    public void addToZip(String qfolder, String questionId, FileEntity fileEntity, ZipOutputStream zos)
            throws IOException {
        String zipFilePath = getZipFileName(qfolder, questionId, fileEntity);
        LOGGER.info("Writing '" + zipFilePath + "' to zip file");
        FileContentEntity fileContent = fileEntity.getFileContentEntity();
        byte[] fileBytes = fileContent.getFileContent();
        byte[] uncompressed = FileUtil.gzipUncompress(fileBytes);
        ZipEntry zipEntry = new ZipEntry(zipFilePath);
        zipEntry.setSize(uncompressed.length);
        zos.putNextEntry(zipEntry);
        zos.write(uncompressed);
        zos.closeEntry();
    }

    private String getZipFileName(String qfolder, String questionId, FileEntity fileEntity) {
        String zipFilePath = qfolder + "\\" + questionId + "_" + Long.toString(fileEntity.getId()) + "_"
                + fileEntity.getOriginalFileName();
        return zipFilePath;
    }

}