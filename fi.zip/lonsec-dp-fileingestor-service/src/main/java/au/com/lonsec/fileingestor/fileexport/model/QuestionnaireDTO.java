package au.com.lonsec.fileingestor.fileexport.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Batch Model representation for Batch entity.
 * 
 * @author MCheung
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "questionnaireName", "files" })
public class QuestionnaireDTO {

    private String questionnaireName;

    private List<ExportFileDTO> files;

    public String getQuestionnaireName() {
        return questionnaireName;
    }

    public void setQuestionnaireName(String questionnaireName) {
        this.questionnaireName = questionnaireName;
    }

    public List<ExportFileDTO> getFiles() {
        return files;
    }

    public void setFiles(List<ExportFileDTO> files) {
        this.files = files;
    }

}
