package au.com.lonsec.fileingestor.fileupload.model;

import java.util.List;
import java.util.Map;

public class SectionDTO {

    private String sheetName;

    private String sectionName;

    private List<Map<String, Object>> dataRows;

    private List<ValidationDTO> validationDTOs;

    public String getSheetName() {
        return sheetName;
    }

    public void setSheetName(String sheetName) {
        this.sheetName = sheetName;
    }

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    public List<Map<String, Object>> getDataRows() {
        return dataRows;
    }

    public void setDataRows(List<Map<String, Object>> dataRows) {
        this.dataRows = dataRows;
    }

    public List<ValidationDTO> getValidationDTOs() {
        return validationDTOs;
    }

    public void setValidationDTOs(List<ValidationDTO> validationDTOs) {
        this.validationDTOs = validationDTOs;
    }

}
