package au.com.lonsec.fileingestor.fileupload;

public class FileSpecNotFoundException extends Exception {

    private static final long serialVersionUID = -6022065019378181801L;

    public FileSpecNotFoundException(String message) {
        super(message);
    }

}
