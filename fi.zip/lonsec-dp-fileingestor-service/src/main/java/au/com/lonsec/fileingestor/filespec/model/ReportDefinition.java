package au.com.lonsec.fileingestor.filespec.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import au.com.lonsec.fileingestor.validation.model.ValidationRule;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "headerStartRow", "dataStartRow", "columnDefinitions", "validationRules" })
public class ReportDefinition {

    private int headerStartRow;
    private int dataStartRow;

    private List<ColumnDefinition> columnDefinitions;

    private List<ValidationRule> validationRules;

    private List<ValidationRule> groupValidationRules;

    private List<ValidationRule> sectionValidationRules;

    public int getHeaderStartRow() {
        return headerStartRow;
    }

    public void setHeaderStartRow(int headerStartRow) {
        this.headerStartRow = headerStartRow;
    }

    public int getDataStartRow() {
        return dataStartRow;
    }

    public void setDataStartRow(int dataStartRow) {
        this.dataStartRow = dataStartRow;
    }

    public List<ColumnDefinition> getColumnDefinitions() {
        return columnDefinitions;
    }

    public void setColumnDefinitions(List<ColumnDefinition> columnDefinitions) {
        this.columnDefinitions = columnDefinitions;
    }

    public List<ValidationRule> getValidationRules() {
        return validationRules;
    }

    public void setValidationRules(List<ValidationRule> validationRules) {
        this.validationRules = validationRules;
    }

    public List<ValidationRule> getGroupValidationRules() {
        return groupValidationRules;
    }

    public void setGroupValidationRules(List<ValidationRule> groupValidationRules) {
        this.groupValidationRules = groupValidationRules;
    }

    public List<ValidationRule> getSectionValidationRules() {
        return sectionValidationRules;
    }

    public void setSectionValidationRules(List<ValidationRule> sectionValidationRules) {
        this.sectionValidationRules = sectionValidationRules;
    }

}
