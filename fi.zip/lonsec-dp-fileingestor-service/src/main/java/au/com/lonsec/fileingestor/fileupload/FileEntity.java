package au.com.lonsec.fileingestor.fileupload;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.lonsec.fileingestor.base.AbstractEntity;

/**
 * File Model representation for File entity.
 * 
 * @author MCheung
 */

@Entity
@Table(name = "fileitem")
public class FileEntity extends AbstractEntity {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "id", updatable = false, nullable = false)
    private Long id;

    @NotEmpty
    @Column(name = "original_file_name")
    private String originalFileName;

    @Column(name = "batch_id")
    private Long batchId;

    @Column(name = "status")
    private String status;

    @Column(name = "fail_reason")
    private String failReason;

    @Column(name = "total_datasets")
    private int totalDatasets;

    @Column(name = "error_datasets")
    private int errorDatasets;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "file_content_id")
    private FileContentEntity fileContentEntity;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOriginalFileName() {
        return originalFileName;
    }

    public void setOriginalFileName(String originalFileName) {
        this.originalFileName = originalFileName;
    }

    public Long getBatchId() {
        return batchId;
    }

    public void setBatchId(Long batchId) {
        this.batchId = batchId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


    public String getFailReason() {
        return failReason;
    }

    public void setFailReason(String failReason) {
        this.failReason = failReason;
    }

    public int getTotalDatasets() {
        return totalDatasets;
    }

    public void setTotalDatasets(int totalDatasets) {
        this.totalDatasets = totalDatasets;
    }

    public int getErrorDatasets() {
        return errorDatasets;
    }

    public void setErrorDatasets(int errorDatasets) {
        this.errorDatasets = errorDatasets;
    }

    public FileContentEntity getFileContentEntity() {
        return fileContentEntity;
    }

    public void setFileContentEntity(FileContentEntity fileContentEntity) {
        this.fileContentEntity = fileContentEntity;
    }
    
    

}
