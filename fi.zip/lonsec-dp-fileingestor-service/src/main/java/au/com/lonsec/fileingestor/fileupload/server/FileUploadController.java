package au.com.lonsec.fileingestor.fileupload.server;

import static org.springframework.http.HttpStatus.ACCEPTED;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import au.com.lonsec.fileingestor.fileexport.model.ExportQuestionnaireDTO;
import au.com.lonsec.fileingestor.fileupload.FileExportService;
import au.com.lonsec.fileingestor.fileupload.FileIngestorService;
import au.com.lonsec.fileingestor.fileupload.FileStoreAndFowardService;
import au.com.lonsec.fileingestor.fileupload.model.BatchDTO;
import au.com.lonsec.fileingestor.fileupload.model.FileDTO;
import au.com.lonsec.fileingestor.fileupload.model.ResultDTO;

@RestController
@RequestMapping(value = FileUploadURI.FILEINGESTOR_BASE_CONTEXT)
public class FileUploadController {

    @Autowired
    private FileIngestorService fileIngestorService;

    @Autowired
    private FileStoreAndFowardService fileStoreAndFowardService;
    
    
    @Autowired
    private FileExportService fileExportService;

    @RequestMapping(value = FileUploadURI.POST_UPLOAD_MAPPING, method = POST)
    @ResponseStatus(ACCEPTED)
    @ResponseBody
    public ResponseEntity<ResultDTO> uploadHoldingFile(@RequestParam(value = "file", required = true) MultipartFile uploadfile,
            @RequestParam(value = "name", defaultValue = "portfolioHoldingDef", required = true) String fileSpec,
            @RequestHeader(value = "Authorization", required = false) final String authToken) throws IOException, OpenXML4JException {
        ResultDTO result = fileIngestorService.importData(uploadfile, fileSpec);
        return new ResponseEntity<ResultDTO>(result, HttpStatus.ACCEPTED);

    }

    @RequestMapping(value = FileUploadURI.POST_MULTI_FILEUPLOAD_MAPPING, method = POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseStatus(ACCEPTED)
    @ResponseBody
    public ResponseEntity<BatchDTO> multiuploadFileStoreAndFwd(
            @RequestParam(value = "inputFiles", required = true) MultipartFile[] inputFiles,
            @RequestParam(value = "batchId", required = false) Long batchId,
            @RequestHeader(value = "Content-Type", required = false) final String contentType,
            @RequestHeader(value = "Authorization", required = false) final String authToken) throws IOException, InterruptedException {
        BatchDTO batchEntity = fileStoreAndFowardService.storeAndFwd(inputFiles, batchId, true);
        return new ResponseEntity<BatchDTO>(batchEntity, HttpStatus.ACCEPTED);
    }
    
    
    
    @RequestMapping(value = FileUploadURI.POST_FILE_DOWNLOAD_MAPPING, method = POST)
    @ResponseStatus(ACCEPTED)
    @ResponseBody
    public ResponseEntity<byte[]> fileDownLoad(
            @RequestBody ExportQuestionnaireDTO exportRequest,
            @RequestHeader(value = "Content-Type", required = false) final String contentType,
            @RequestHeader(value = "Authorization", required = false) final String authToken) throws IOException, InterruptedException {
           String result = "ok";
           byte[] bytes = fileExportService.exportFiles(exportRequest);
           MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
           headers.add("Content-Type", "application/octet-stream");
           headers.add("Content-Disposition", "attachment; filename=\"zipFile.zip\"");
           return new ResponseEntity<>(bytes, headers, HttpStatus.OK);
    }


    @RequestMapping(value = FileUploadURI.POST_STATIC_MULTI_FILEUPLOAD_MAPPING, method = POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseStatus(ACCEPTED)
    @ResponseBody
    public ResponseEntity<BatchDTO> multiuploadStaticFileStore(
            @RequestParam(value = "inputFiles", required = true) MultipartFile[] inputFiles,
            @RequestParam(value = "batchId", required = false) Long batchId,
            @RequestHeader(value = "Content-Type", required = false) final String contentType,
            @RequestHeader(value = "Authorization", required = false) final String authToken) throws IOException, InterruptedException {
        BatchDTO batchEntity = fileStoreAndFowardService.storeAndFwd(inputFiles, batchId, false);
        return new ResponseEntity<BatchDTO>(batchEntity, HttpStatus.ACCEPTED);
    }

    @RequestMapping(value = FileUploadURI.GET_BATCH_STATUS_MAPPING, method = GET)
    @ResponseStatus(OK)
    @ResponseBody
    public ResponseEntity<BatchDTO> getBatchStatus(@RequestParam(value = "batchId", required = true) Long batchId,
            @RequestHeader(value = "Content-Type", required = false) final String contentType,
            @RequestHeader(value = "Authorization", required = false) final String authToken) {
        BatchDTO batchDTO = fileIngestorService.getBatchSummary(batchId);
        return new ResponseEntity<BatchDTO>(batchDTO, HttpStatus.OK);
    }

    @RequestMapping(value = FileUploadURI.GET_FILE_ERRORS_MAPPING, method = GET)
    @ResponseStatus(OK)
    @ResponseBody
    public ResponseEntity<FileDTO> getFileErrors(@RequestParam(value = "fileId", required = true) Long fileId,
            @RequestHeader(value = "Content-Type", required = false) final String contentType,
            @RequestHeader(value = "Authorization", required = false) final String authToken)
            throws JsonParseException, JsonMappingException, IOException {
        FileDTO fileDTO = fileIngestorService.getFileErrors(fileId);
        return new ResponseEntity<FileDTO>(fileDTO, HttpStatus.OK);
    }

}
