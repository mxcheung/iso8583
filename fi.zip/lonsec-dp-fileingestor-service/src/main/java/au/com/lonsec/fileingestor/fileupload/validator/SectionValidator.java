package au.com.lonsec.fileingestor.fileupload.validator;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.lonsec.fileingestor.filespec.model.ColumnDefinition;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;
import au.com.lonsec.fileingestor.fileupload.model.DataSetDTO;
import au.com.lonsec.fileingestor.fileupload.model.SectionDTO;
import au.com.lonsec.fileingestor.fileupload.model.ValidationDTO;

@Service
public class SectionValidator {

    private static final Logger LOGGER = LoggerFactory.getLogger(SectionValidator.class);

    private final GroupValidator groupValidator;

    private final RowValidator rowValidator;

    @Autowired
    SectionValidator(GroupValidator groupValidator, RowValidator rowValidator) {
        this.groupValidator = groupValidator;
        this.rowValidator = rowValidator;
    }

    public DataSetDTO validateSection(ReportDefinition reportDefinition, SectionDTO sectionDTO) {

        LOGGER.info("validating section" + sectionDTO.getSectionName());

        List<ColumnDefinition> columns = reportDefinition.getColumnDefinitions();

        List<Map<String, Object>> dataRows = sectionDTO.getDataRows();

        List<ValidationDTO> validationDTOs = convertTovalidationDTOs(columns, dataRows);

        rowValidator.validateRows(reportDefinition, validationDTOs);
        ValidationDTO groupvalidationDTO = new ValidationDTO();
        groupvalidationDTO.setGroupName("GroupValidation");
        groupvalidationDTO.setDataRows(dataRows);
        groupvalidationDTO = groupValidator.validateGroupData(reportDefinition, groupvalidationDTO);
        DataSetDTO dataSetDTO = generateDataSet(sectionDTO, validationDTOs, groupvalidationDTO);
        return dataSetDTO;
    }

    public DataSetDTO generateDataSet(SectionDTO sectionDTO, List<ValidationDTO> validationDTOs, ValidationDTO groupvalidationDTO) {
        List<ValidationDTO> validationDTOErrors = validationDTOs.stream().filter(validationDTOX -> validationDTOX.isContainsErrors())
                .collect(Collectors.toList());

        // do not return data
        groupvalidationDTO.setDataRows(null);
        if (groupvalidationDTO.isContainsErrors()) {
            validationDTOErrors.add(groupvalidationDTO);
        }

        DataSetDTO result = new DataSetDTO();
        result.setDataRows(validationDTOErrors);
        result.setTotalRows(validationDTOs.size());
        result.setErrorRows(validationDTOErrors.size());
        result.setContainsErrors(validationDTOErrors.size() > 0);
        result.setDataSetName(sectionDTO.getSheetName());
        result.setSectionName(sectionDTO.getSectionName());
        return result;
    }

    private List<ValidationDTO> convertTovalidationDTOs(List<ColumnDefinition> columns, List<Map<String, Object>> dataRows) {
        List<ValidationDTO> validationDTOs = new ArrayList<ValidationDTO>();
        for (Map<String, Object> dataRow : dataRows) {
            ValidationDTO validationDTO = new ValidationDTO();
            validationDTO.setData(dataRow);
            validationDTOs.add(validationDTO);
        }
        return validationDTOs;
    }

}
