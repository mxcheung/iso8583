package au.com.lonsec.fileingestor.fileupload.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "fileName", "totalDatasets", "errorDatasets", "dataSets" })
public class ResultDTO {

    private String fileName;

    private List<DataSetDTO> dataSets;

    private int totalDatasets;

    private int errorDatasets;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public List<DataSetDTO> getDataSets() {
        return dataSets;
    }

    public void setDataSets(List<DataSetDTO> dataSets) {
        this.dataSets = dataSets;
    }

    public int getTotalDatasets() {
        return totalDatasets;
    }

    public void setTotalDatasets(int totalDatasets) {
        this.totalDatasets = totalDatasets;
    }

    public int getErrorDatasets() {
        return errorDatasets;
    }

    public void setErrorDatasets(int errorDatasets) {
        this.errorDatasets = errorDatasets;
    }

}
