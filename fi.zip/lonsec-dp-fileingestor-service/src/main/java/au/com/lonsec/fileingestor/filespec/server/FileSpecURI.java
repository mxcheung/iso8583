package au.com.lonsec.fileingestor.filespec.server;

/**
 * @author MAX see https://studio.restlet.com/apis/local/sections/Companies
 *         https://hello-angularjs.appspot.com/searchtable
 */
public final class FileSpecURI {

    public static final String FILESPEC_BASE_CONTEXT = "/filespec";

    public static final String GET_REPORT_DEFINITION = "/api/reportDefinition";

    private FileSpecURI() {
    }

}