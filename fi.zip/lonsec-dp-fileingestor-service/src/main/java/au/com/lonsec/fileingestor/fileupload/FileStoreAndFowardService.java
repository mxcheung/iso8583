package au.com.lonsec.fileingestor.fileupload;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import au.com.lonsec.fileingestor.fileexport.model.ExportQuestionnaireDTO;
import au.com.lonsec.fileingestor.fileupload.model.BatchDTO;
import au.com.lonsec.fileingestor.fileupload.model.FileDTO;
import au.com.lonsec.fileingestor.queue.FileProducer;
import au.com.lonsec.fileingestor.util.FileUtil;

@Service
public class FileStoreAndFowardService {

    private static final String QUEUED = FileStatusType.QUEUED.name();
    private static final String STORED = FileStatusType.STORED.name();

    private static final Logger LOGGER = LoggerFactory.getLogger(FileStoreAndFowardService.class);

    private final FileService fileService;

    private final FileContentRepository fileContentRepository;

    private final BatchRepository batchRepository;

    private final FileMapper fileMapper;

    private final FileProducer fileProducer;

    @Autowired
    public FileStoreAndFowardService(FileMapper fileMapper, BatchRepository batchRepository, FileProducer fileProducer, FileService fileService,
            FileContentRepository fileContentRepository) {
        this.fileMapper = fileMapper;
        this.fileProducer = fileProducer;
        this.batchRepository = batchRepository;
        this.fileService = fileService;
        this.fileContentRepository = fileContentRepository;
    }

    public FileEntity storeAndFwd(MultipartFile multipartFile, Long batchId, boolean storeAndFwd) throws IOException, InterruptedException {
        FileEntity fileEntity = storeFile(multipartFile, batchId, storeAndFwd);
        if (storeAndFwd) {
            QueueItemEntity queueItemEntity = new QueueItemEntity();
            queueItemEntity.setFileId(fileEntity.getId());
            fileProducer.put(queueItemEntity);
        }
        return fileEntity;
    }

    private FileEntity storeFile(MultipartFile multipartFile, Long batchId, boolean storeAndFwd) throws IOException {
        String status = getFileStatus(storeAndFwd);
        String originalFileName = multipartFile.getOriginalFilename();
        LOGGER.info("Storing file {}", originalFileName);
        byte[] byteArr = null;
        byteArr = multipartFile.getBytes();
        FileEntity fileEntity = new FileEntity();
        FileContentEntity fileContentEntity = new FileContentEntity();
        fileEntity.setFileContentEntity(fileContentEntity);
        fileEntity.setOriginalFileName(originalFileName);
        byte[] compressedData = FileUtil.gzipCompress(byteArr);
        fileContentEntity.setFileContent(compressedData);
        fileEntity.setBatchId(batchId);
        fileEntity.setStatus(status);
        fileContentRepository.save(fileContentEntity);
        fileService.save(fileEntity);
        return fileEntity;
    }

    public String getFileStatus(boolean storeAndFwd) {
        String status = storeAndFwd ? QUEUED : STORED;
        return status;
    }

    public BatchDTO storeAndFwd(MultipartFile[] mpFiles, Long batchId, boolean storeAndFwd) throws IOException, InterruptedException {
        BatchEntity batchEntity = findOrCreate(batchId);
        Long newBatchId = batchEntity.getId();
        BatchDTO batchDTO = new BatchDTO();
        batchDTO.setId(newBatchId);
        List<FileEntity> fileEntitys = new ArrayList<FileEntity>();
        for (MultipartFile file : mpFiles) {
            FileEntity fileEntity = storeAndFwd(file, newBatchId, storeAndFwd);
            fileEntitys.add(fileEntity);
        }
        batchDTO.setFiles(convert(fileEntitys));
        return batchDTO;
    }

    public BatchEntity findOrCreate(Long batchId) {
        BatchEntity batchEntity = null;
        if (batchId != null) {
            batchEntity = batchRepository.findOne(batchId);
        }
        if (batchEntity == null) {
            batchEntity = new BatchEntity();
            batchEntity = batchRepository.save(batchEntity);
        }
        return batchEntity;
    }

    public List<FileDTO> convert(List<FileEntity> fileEntitys) {
        List<FileDTO> fileDTOs = new ArrayList<FileDTO>();
        for (FileEntity fileEntity : fileEntitys) {
            FileDTO fileDTO = fileMapper.map(fileEntity, new FileDTO());
            fileDTOs.add(fileDTO);
        }
        return fileDTOs;
    }

    @Transactional
    public byte[] exportFiles(ExportQuestionnaireDTO exportRequest) {
        Long fileId = 1L;
        FileEntity fileEntity = fileService.fetchFileEntity(fileId );
        FileContentEntity fileContent = fileEntity.getFileContentEntity();
        byte[] fileBytes = fileContent.getFileContent();
        return fileBytes;
    }
}