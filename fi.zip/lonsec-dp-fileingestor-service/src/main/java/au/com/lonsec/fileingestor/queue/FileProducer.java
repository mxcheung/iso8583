package au.com.lonsec.fileingestor.queue;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import au.com.lonsec.fileingestor.fileupload.QueueItemEntity;
import au.com.lonsec.fileingestor.fileupload.QueueRepository;

@Service
public class FileProducer {

    private static final Logger LOGGER = LoggerFactory.getLogger(FileProducer.class);

    private final QueueRepository queueRepository;
    private final FileIngestorQueueService fileIngestorQueueService;

    public FileProducer(QueueRepository queueRepository, 
            FileIngestorQueueService fileIngestorQueueService) throws InterruptedException {
        this.queueRepository = queueRepository;
        this.fileIngestorQueueService = fileIngestorQueueService;
    }

    public void recoverJobs() throws InterruptedException {
        List<QueueItemEntity> items = queueRepository.findAll();
        LOGGER.info("Resuming of job count:  {} ", items.size());
        for (QueueItemEntity item : items) {
            fileIngestorQueueService.put(item);
        }
    }

    public void put(QueueItemEntity item) throws InterruptedException {
        queueRepository.save(item);
        fileIngestorQueueService.put(item);
    }

}
