
---------------------------------------------------------------------------------------
-- Setup BATCH Table
---------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS batchitem( 
    id INT NOT NULL, 
    INSERT_DATE TIMESTAMP, 
    LAST_MODIFIED TIMESTAMP, 
    PRIMARY KEY (id) 
);



CREATE TABLE IF NOT EXISTS fileitem( 
    id INT NOT NULL, 
    BATCH_ID BIGINT, 
    ORIGINAL_FILE_NAME VARCHAR(255), 
    STATUS VARCHAR(255), 
    file_content_id INT, 
    fail_reason VARCHAR(255), 
    total_datasets INT, 
    error_datasets INT, 
    INSERT_DATE TIMESTAMP, 
    LAST_MODIFIED TIMESTAMP, 
    PRIMARY KEY (id)     
);


---------------------------------------------------------------------------------------
-- Setup filecontent Table
---------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS filecontent( 
    id INT NOT NULL, 
    file_content BLOB, 
    result_content BLOB 
);


CREATE TABLE IF NOT EXISTS QUEUEITEM( 
    id INT NOT NULL, 
    INSERT_DATE TIMESTAMP, 
    LAST_MODIFIED TIMESTAMP, 
    file_id INT,
    PRIMARY KEY (id) 
);


---------------------------------------------------------------------------------------
-- select id , batch_id, ORIGINAL_FILE_NAME , status , result from FILEITEM ;
---------------------------------------------------------------------------------------

