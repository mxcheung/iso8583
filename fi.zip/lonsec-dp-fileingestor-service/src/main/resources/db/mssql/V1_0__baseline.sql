

---------------------------------------------------------------------------------------
-- Setup batchitem Table
---------------------------------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[batchitem]') AND type in (N'U'))
BEGIN
CREATE TABLE  batchitem (
    id int  NOT NULL, 
    insert_date datetime, 
    last_modified datetime 
    PRIMARY KEY (id) 
)
END;

---------------------------------------------------------------------------------------
-- Setup fileitem Table
---------------------------------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[fileitem]') AND type in (N'U'))
BEGIN
CREATE TABLE  fileitem (
    id int  NOT NULL, 
    batch_id BIGINT, 
    original_file_name VARCHAR(255), 
    status VARCHAR(255),
    file_content_id int  NOT NULL,
    fail_reason VARCHAR(255), 
    total_datasets int   NULL, 
    error_datasets int   NULL,
    insert_date datetime, 
    last_modified datetime 
    PRIMARY KEY (id) 
)
END;

---------------------------------------------------------------------------------------
-- Setup filecontent Table
---------------------------------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[filecontent]') AND type in (N'U'))
BEGIN
CREATE TABLE  filecontent (
    id int  NOT NULL, 
    file_content VARBINARY(MAX), 
    result_content VARBINARY(MAX) 
    PRIMARY KEY (id) 
)
END;

---------------------------------------------------------------------------------------
-- Setup queueitem Table
---------------------------------------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[queueitem]') AND type in (N'U'))
BEGIN
CREATE TABLE  queueitem (
    id int  NOT NULL,
    file_id INT,
    insert_date datetime, 
    last_modified datetime 
    PRIMARY KEY (id) 
)
END;

---------------------------------------------------------------------------------------
-- select id , batch_id, ORIGINAL_FILE_NAME , status , result from FILEITEM ;
-- drop table batchitem;
-- drop table fileitem;
-- drop table filecontent;
-- drop table queueitem;
-- drop table schema_version;
---------------------------------------------------------------------------------------

