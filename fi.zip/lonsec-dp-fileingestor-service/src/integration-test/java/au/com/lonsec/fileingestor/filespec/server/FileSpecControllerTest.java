package au.com.lonsec.fileingestor.filespec.server;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;

import au.com.lonsec.fileingestor.domain.DomainStereotypeUtil;
import au.com.lonsec.fileingestor.filespec.FileSpecService;
import au.com.lonsec.fileingestor.filespec.model.ReportDefinition;

@RunWith(SpringRunner.class)
@WebMvcTest(value = FileSpecController.class, secure = false)
public class FileSpecControllerTest {

	protected static final String SEGMENT_CD = "SR";
	protected static final String FILE_SPEC = "Holding";

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private FileSpecService fileSpecService;

	private ReportDefinition reportDefinition;

	@Before
	public void setup() {
		reportDefinition = DomainStereotypeUtil.getReportDefinition();
	}

	@Test
	public void shouldFindReportDefinition() throws Exception {
		when(fileSpecService.getReportDefinition(FILE_SPEC)).thenReturn(reportDefinition);
		MockHttpServletResponse response = getEndpoint(FileSpecURI.GET_REPORT_DEFINITION);
		assertEquals(HttpStatus.OK.value(), response.getStatus());
	}

	@Test
	public void shouldRejectInvalidURL() throws Exception {
		MockHttpServletResponse response = getEndpoint("/doesNotExist");
		assertEquals(HttpStatus.NOT_FOUND.value(), response.getStatus());
	}

	private MockHttpServletResponse getEndpoint(String endpoint) throws JsonProcessingException, Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.get(FileSpecURI.FILESPEC_BASE_CONTEXT + endpoint, FILE_SPEC).header("segmentCd", SEGMENT_CD)
				.accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		return result.getResponse();
	}

}
